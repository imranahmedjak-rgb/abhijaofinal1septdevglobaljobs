#!/usr/bin/env bash
set -Eeuo pipefail
APP="/var/www/devglobaljobs"
DIST="$APP/dist"
PUBLIC="$DIST/public"
ASSETS="$PUBLIC/assets"
PM2_APP="devglobaljobs"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/var/backups/devglobaljobs-premium-employer-v48-${STAMP}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$HERE/payload"

# Exact successful V46 live baseline.
BASE_SERVER_SHA="62553713761f298ec7dd50a50f32b920494f9624a6f9f0648378239fd408bb94"
BASE_INDEX_SHA="0fa228659d896bb2fa081462c64a78cd6cd60632ca1a92d053f12553bf8b9dbd"
BASE_V46_MODULE_SHA="f66fe32c6c7800ccfa4d7963edd2d5025f323938bdb190fdb4b3a6e8a039b1ca"
BASE_V46_UI_SHA="870938e63e0e1807f22a6fa14ffef636ddb4b37717d7281c28318f74b1057bbb"
BASE_V46_CSS_SHA="d541842ee81e1b7e9256a32bff9654709d1ff6c78edae7fb2c91a9762a195b9c"
BASE_V45_MODULE_SHA="d8ba3950fc169dfaa94fa061b466dd3152bc969a375b6e31ed87f7155af09b0f"
BASE_V45_UI_SHA="a52126b670737e30dd6f929fb6f901d2e66bf99f899d65a22199ce3e0952a801"
BASE_V45_CSS_SHA="cd3038190e9fc212058fd53bdf506b6bd28661764fdb083605e589d54819dfe7"
BASE_V45_LOGO_SHA="66d36152a4de7a1f2d7270a3901ebc204cc4592ca66f93a2370a6110d4eb05ea"
BASE_MAIN_SHA="ff420f2b6b88f06f5a9f6c9e3bc2ae88b456bbca5bb6a76b3047992874a909df"
BASE_GOOGLE_JOBS_SHA="efd02864b5ea0703465ab7d62a6b8dc43d7a48e0ea074082a45f6a7adc23ddf6"
BASE_SOCIAL_SHA="528878c345ddf89bde59041513d2b406fb1c8bcb786ee9874413247a6a6cbd92"
BASE_CONTRACT_SHA="00e06a8e7592a5aff18fcfa21492b43a2ad513c46a473d45f45367c7765295b4"
BASE_SW_SHA="7f6986e064891c43437df7f35fd4c2a7050d1ce82bd0120b12afb7e9fa1733f3"
BASE_BRAND_JS_SHA="c65297262b99483d6fa87e4a2e469417e98592162329d1f1646dfab91e02fdd4"

NEW_SERVER_SHA="754afef80c982fd75e6373d839893858a85f42909589da5ffd29d59c2fdbcd0c"
NEW_INDEX_SHA="1ea7a0b5e404e114315818205fa274548783af3f5894bb3d86c974094e7a15d6"
NEW_JS_SHA="a1eb6a365c41648762f924e9051940930bbc273c5d93d61fb134f0c8cf3b580b"
NEW_CSS_SHA="a17de7c0bbf56a6c572c308e3be60c2a8f95f3e3cdff294157f4b030acb06f2e"

MUTATED=0
sha(){ sha256sum "$1" | awk '{print $1}'; }
fail(){ echo; echo "============================================================"; echo "SAFE STOP: $*"; echo "NOTHING UNVERIFIED WILL BE KEPT."; echo "============================================================"; exit 1; }
rollback(){
  local rc=$?
  if [ "$MUTATED" = "1" ]; then
    echo; echo "ROLLBACK: restoring exact pre-V48 V46 production files..."; set +e
    [ -f "$BACKUP/index.cjs" ] && cp -af "$BACKUP/index.cjs" "$DIST/index.cjs"
    [ -f "$BACKUP/index.html" ] && cp -af "$BACKUP/index.html" "$PUBLIC/index.html"
    if [ -f "$BACKUP/dgj-v48-premium.js" ]; then cp -af "$BACKUP/dgj-v48-premium.js" "$ASSETS/dgj-v48-premium.js"; else rm -f "$ASSETS/dgj-v48-premium.js"; fi
    if [ -f "$BACKUP/dgj-v48-premium.css" ]; then cp -af "$BACKUP/dgj-v48-premium.css" "$ASSETS/dgj-v48-premium.css"; else rm -f "$ASSETS/dgj-v48-premium.css"; fi
    pm2 reload "$PM2_APP" --update-env >/dev/null 2>&1 || true
    echo "ROLLBACK COMPLETE. Exact V46 runtime/index restored."
    set -e
  fi
  exit "$rc"
}
trap rollback ERR INT TERM

echo "============================================================"
echo "DEV GLOBAL JOBS V48"
echo "PREMIUM EMPLOYER DASHBOARD + FORM-ONLY PUBLISHING"
echo "ZERO-FLASH EMPLOYER/AUTH + ADMIN WORKFLOW"
echo "============================================================"
[ "$(id -u)" = "0" ] || fail "Run as root."
for c in sha256sum node curl pm2 install grep mkdir cp mv chmod find stat; do command -v "$c" >/dev/null 2>&1 || fail "Required command missing: $c"; done
[ -d "$ASSETS" ] || fail "Public assets directory missing."

echo; echo "1/8 EXACT SUCCESSFUL V46 BASELINE + HEALTH"
[ "$(sha "$DIST/index.cjs")" = "$BASE_SERVER_SHA" ] || fail "Live server is not exact successful V46 baseline. Do not stack V48 on an unknown runtime."
[ "$(sha "$PUBLIC/index.html")" = "$BASE_INDEX_SHA" ] || fail "Live public index is not exact successful V46 baseline."
[ "$(sha "$DIST/dgj-v46-employer.cjs")" = "$BASE_V46_MODULE_SHA" ] || fail "V46 employer module changed."
[ "$(sha "$ASSETS/dgj-v46-employer.js")" = "$BASE_V46_UI_SHA" ] || fail "V46 employer UI changed."
[ "$(sha "$ASSETS/dgj-v46-employer.css")" = "$BASE_V46_CSS_SHA" ] || fail "V46 employer CSS changed."
[ "$(sha "$DIST/dgj-v45-commercial.cjs")" = "$BASE_V45_MODULE_SHA" ] || fail "V45 commercial module changed."
[ "$(sha "$ASSETS/dgj-v45-commercial.js")" = "$BASE_V45_UI_SHA" ] || fail "V45 commercial UI changed."
[ "$(sha "$ASSETS/dgj-v45-commercial.css")" = "$BASE_V45_CSS_SHA" ] || fail "V45 commercial CSS changed."
[ "$(sha "$ASSETS/dgj-admin-logo-v45.png")" = "$BASE_V45_LOGO_SHA" ] || fail "Employer/Admin logo changed."
[ "$(sha "$ASSETS/index-DGJ45auth-v43-youth.js")" = "$BASE_MAIN_SHA" ] || fail "V44 Youth SPA changed."
[ "$(sha "$PUBLIC/dgj-google-jobs-v27.js")" = "$BASE_GOOGLE_JOBS_SHA" ] || fail "Google Jobs companion changed."
[ "$(sha "$PUBLIC/devglobaljobs-social-share.png")" = "$BASE_SOCIAL_SHA" ] || fail "Social preview changed."
[ "$(sha "$PUBLIC/brand-contract.json")" = "$BASE_CONTRACT_SHA" ] || fail "Brand contract changed."
[ "$(sha "$PUBLIC/sw.js")" = "$BASE_SW_SHA" ] || fail "Service worker changed."
[ "$(sha "$PUBLIC/dgj-brand-contract-v27.js")" = "$BASE_BRAND_JS_SHA" ] || fail "Brand JS changed."
curl -fsS --max-time 20 http://127.0.0.1:8080/api/jobs/stats >/dev/null || fail "Local API unhealthy."
pm2 describe "$PM2_APP" | grep -q 'online' || fail "PM2 app not online."
echo "PASS: exact successful V46 baseline verified."

echo; echo "2/8 V48 PACKAGE + PREMIUM WORKFLOW VALIDATION"
[ "$(sha "$PAYLOAD/dist/index.cjs")" = "$NEW_SERVER_SHA" ] || fail "V48 runtime checksum mismatch."
[ "$(sha "$PAYLOAD/dist/public/index.html")" = "$NEW_INDEX_SHA" ] || fail "V48 index checksum mismatch."
[ "$(sha "$PAYLOAD/dist/public/assets/dgj-v48-premium.js")" = "$NEW_JS_SHA" ] || fail "V48 JS checksum mismatch."
[ "$(sha "$PAYLOAD/dist/public/assets/dgj-v48-premium.css")" = "$NEW_CSS_SHA" ] || fail "V48 CSS checksum mismatch."
node --check "$PAYLOAD/dist/index.cjs" >/dev/null
node --check "$PAYLOAD/dist/public/assets/dgj-v48-premium.js" >/dev/null
grep -Fq 'DGJ V48_PREMIUM_EMPLOYER_ZERO_FLASH_LOCK' "$PAYLOAD/dist/index.cjs" || fail "V48 server marker missing."
grep -Fq 'app2.get("/employer/post-job"' "$PAYLOAD/dist/index.cjs" || fail "Server-owned employer post route missing."
grep -Fq 'Employer Sign In to Post a Job' "$PAYLOAD/dist/index.cjs" || fail "Employer-only unauthenticated Post a Job missing."
grep -Fq 'dgj48-post-form-only' "$PAYLOAD/dist/public/assets/dgj-v48-premium.js" || fail "Form-only employer publishing missing."
grep -Fq 'dgj48-public-chrome' "$PAYLOAD/dist/public/assets/dgj-v48-premium.js" || fail "Nested public-site chrome suppression missing."
grep -Fq 'Premium Employer Workspace' "$PAYLOAD/dist/public/assets/dgj-v48-premium.css" || fail "Premium Employer Workspace styling missing."
echo "PASS: premium Employer Dashboard, clean Post a Job and zero-flash workflow payload verified."

echo; echo "3/8 PROTECTED V46 / V45 / SEO / BRAND CHECK"
for marker in 'DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27' 'devglobaljobs-social-share.png' 'const indexableJobs = latestJobs;' 'const indexableJobs = jobIds;' 'const indexableJobs = allJobIds;'; do grep -Fq "$marker" "$PAYLOAD/dist/index.cjs" || fail "Protected runtime marker missing: $marker"; done
if find "$PAYLOAD" -type f \( -name 'dgj-v45-commercial.cjs' -o -name 'dgj-v45-commercial.js' -o -name 'dgj-v45-commercial.css' -o -name 'dgj-v46-employer.cjs' -o -name 'dgj-v46-employer.js' -o -name 'dgj-v46-employer.css' \) -print -quit | grep -q .; then fail "Protected V45/V46 replacement unexpectedly packaged."; fi
echo "PASS: V46 employer data/actions, V45 payments/Boost and protected SEO architecture are not replaced."

echo; echo "4/8 PRIVATE ROLLBACK BACKUP"
mkdir -p "$BACKUP"; chmod 700 "$BACKUP"
cp -af "$DIST/index.cjs" "$BACKUP/index.cjs"
cp -af "$PUBLIC/index.html" "$BACKUP/index.html"
[ -f "$ASSETS/dgj-v48-premium.js" ] && cp -af "$ASSETS/dgj-v48-premium.js" "$BACKUP/dgj-v48-premium.js" || true
[ -f "$ASSETS/dgj-v48-premium.css" ] && cp -af "$ASSETS/dgj-v48-premium.css" "$BACKUP/dgj-v48-premium.css" || true
chmod -R go-rwx "$BACKUP"
echo "Backup: $BACKUP"
echo "PASS: rollback backup is private under /var/backups."

echo; echo "5/8 ATOMIC V48 INSTALL"
tmp_server="$DIST/.index.cjs.v48.$$"; tmp_index="$PUBLIC/.index.html.v48.$$"; tmp_js="$ASSETS/.dgj-v48-premium.js.$$"; tmp_css="$ASSETS/.dgj-v48-premium.css.$$"
install -m 0644 "$PAYLOAD/dist/index.cjs" "$tmp_server"
install -m 0644 "$PAYLOAD/dist/public/index.html" "$tmp_index"
install -m 0644 "$PAYLOAD/dist/public/assets/dgj-v48-premium.js" "$tmp_js"
install -m 0644 "$PAYLOAD/dist/public/assets/dgj-v48-premium.css" "$tmp_css"
mv -f "$tmp_js" "$ASSETS/dgj-v48-premium.js"
mv -f "$tmp_css" "$ASSETS/dgj-v48-premium.css"
mv -f "$tmp_index" "$PUBLIC/index.html"
mv -f "$tmp_server" "$DIST/index.cjs"
MUTATED=1
[ "$(sha "$DIST/index.cjs")" = "$NEW_SERVER_SHA" ]
[ "$(sha "$PUBLIC/index.html")" = "$NEW_INDEX_SHA" ]
[ "$(sha "$ASSETS/dgj-v48-premium.js")" = "$NEW_JS_SHA" ]
[ "$(sha "$ASSETS/dgj-v48-premium.css")" = "$NEW_CSS_SHA" ]
echo "PASS: only runtime/index + two new V48 presentation/workflow assets installed."

echo; echo "6/8 PM2 RELOAD + SERVER-OWNED AUTH/POST ROUTE TESTS"
pm2 reload "$PM2_APP" --update-env
sleep 4
curl -fsS --max-time 20 http://127.0.0.1:8080/api/jobs/stats >/dev/null || false
EMP_CODE="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 20 http://127.0.0.1:8080/api/v46/employer/me || true)"; [ "$EMP_CODE" = "401" ] || { echo "Unexpected unauthenticated employer API code: $EMP_CODE"; false; }
HDR="$(curl -sSI --max-time 20 http://127.0.0.1:8080/employer | tr -d '\r')"; printf '%s' "$HDR" | grep -Eq '^HTTP/.* 302'; printf '%s' "$HDR" | grep -Fiq 'location: /employer/sign-in'
HDR2="$(curl -sSI --max-time 20 http://127.0.0.1:8080/employer/post-job | tr -d '\r')"; printf '%s' "$HDR2" | grep -Eq '^HTTP/.* 302'; printf '%s' "$HDR2" | grep -Fiq 'location: /employer/sign-in?redirect='
POST_SIGNIN="$(curl -fsS --max-time 20 http://127.0.0.1:8080/post-job)"; printf '%s' "$POST_SIGNIN" | grep -Fq 'Dev Global Jobs for Employers'; printf '%s' "$POST_SIGNIN" | grep -Fq 'verified employer email'
echo "PASS: signed-out Post a Job and Employer entry are clean server-owned Employer authentication journeys."

echo; echo "7/8 PROTECTED FILES + PUBLIC SECURITY CHECK"
[ "$(sha "$DIST/dgj-v46-employer.cjs")" = "$BASE_V46_MODULE_SHA" ] || false
[ "$(sha "$ASSETS/dgj-v46-employer.js")" = "$BASE_V46_UI_SHA" ] || false
[ "$(sha "$ASSETS/dgj-v46-employer.css")" = "$BASE_V46_CSS_SHA" ] || false
[ "$(sha "$DIST/dgj-v45-commercial.cjs")" = "$BASE_V45_MODULE_SHA" ] || false
[ "$(sha "$ASSETS/dgj-v45-commercial.js")" = "$BASE_V45_UI_SHA" ] || false
[ "$(sha "$ASSETS/dgj-v45-commercial.css")" = "$BASE_V45_CSS_SHA" ] || false
[ "$(sha "$ASSETS/index-DGJ45auth-v43-youth.js")" = "$BASE_MAIN_SHA" ] || false
[ "$(sha "$PUBLIC/dgj-google-jobs-v27.js")" = "$BASE_GOOGLE_JOBS_SHA" ] || false
[ "$(sha "$PUBLIC/devglobaljobs-social-share.png")" = "$BASE_SOCIAL_SHA" ] || false
[ "$(sha "$PUBLIC/brand-contract.json")" = "$BASE_CONTRACT_SHA" ] || false
[ "$(sha "$PUBLIC/sw.js")" = "$BASE_SW_SHA" ] || false
if find "$PUBLIC" -type f \( -iname '*payment-receipt*' -o -iname '*receipt*.pdf' -o -iname '*receipt*.jpg' -o -iname '*.sql' -o -iname '*.dump' -o -iname '.env*' -o -iname '*.zip' -o -iname '*.tar.gz' -o -iname '*.enc' \) -print -quit | grep -q .; then echo "Sensitive/archive-like file detected under public web root."; false; fi
echo "PASS: V46/V45 protected files unchanged; no obvious sensitive/archive material exposed publicly."

echo; echo "8/8 FINAL ORIGIN + PUBLIC HEALTH"
curl -fsS --max-time 20 http://127.0.0.1:8080/assets/dgj-v48-premium.js?v=48.0.0 >/dev/null || false
curl -fsS --max-time 20 http://127.0.0.1:8080/assets/dgj-v48-premium.css?v=48.0.0 >/dev/null || false
curl -fsS --max-time 20 http://127.0.0.1:8080/sitemap-index.xml | grep -q '<sitemapindex' || false
curl -fsS --max-time 20 https://devglobaljobs.com/ >/dev/null || false

echo; echo "============================================================"
echo "SUCCESS: V48 PREMIUM EMPLOYER WORKSPACE + ZERO-FLASH WORKFLOW IS LIVE"
echo "============================================================"
echo "✓ Employer Dashboard upgraded with premium navigation, cards, spacing and stable scrolling"
echo "✓ Post a Job opens as one Employer Workspace journey, not a nested public website"
echo "✓ Post a Job page keeps listing type + job form and removes redundant public header/marketing/payment clutter"
echo "✓ Current monthly Regular/Featured allowance is shown in a compact employer publishing header"
echo "✓ Free allowance and V45 paid-review logic remain automatic and unchanged"
echo "✓ Signed-out Post a Job goes directly to professional Employer Sign In"
echo "✓ Google/email auth returns cleanly without an unsupported SPA Page Not Found flash"
echo "✓ Employer sign-out uses a controlled secure transition"
echo "✓ Admin login/dashboard transitions are masked and authenticated console scrolling stabilised"
echo "✓ V46 Employer data, analytics, Billing, Plans, Company Profile and Admin Employer Accounts unchanged"
echo "✓ V45 paid posting / receipt upload / emails / Premium Boost / plan codes unchanged"
echo "✓ V44 Youth / Google JobPosting / sitemap / V42 social / service worker / brand lock preserved"
echo "✓ No database schema change in V48"
echo "Rollback backup: $BACKUP"
echo "============================================================"
trap - ERR INT TERM
