#!/usr/bin/env bash
set -Eeuo pipefail
BASE="$(cd "$(dirname "$0")" && pwd)"
P="$BASE/payload/dist/public"
node --check "$P/assets/dgj-v49-premium.js" >/dev/null
node --check "$P/assets/dgj-v51-recruitment.js" >/dev/null
grep -Fq 'dgj53-employer-post' "$P/assets/dgj-v49-premium.js"
grep -Fq 'neutralizeLegacyEmployerPostTransition' "$P/assets/dgj-v51-recruitment.js"
grep -Fq 'dgj-v53-post-route-guard' "$P/index.html"
grep -Fq '/assets/dgj-v49-premium.js?v=53.0.0' "$P/index.html"
grep -Fq '/assets/dgj-v51-recruitment.js?v=53.0.0' "$P/index.html"
! grep -Fq "begin('Opening secure job publishing'" "$P/assets/dgj-v49-premium.js"
grep -Fq 'html.dgj53-employer-post #dgj49-route-transition{display:none!important' "$P/assets/dgj-v51-recruitment.css"
echo 'PASS: V53 unconditional Employer Post a Job route-mask guard verified.'
