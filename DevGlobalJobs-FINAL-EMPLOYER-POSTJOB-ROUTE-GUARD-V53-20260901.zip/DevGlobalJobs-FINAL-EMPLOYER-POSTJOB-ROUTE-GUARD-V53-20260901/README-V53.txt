V53 is a narrow frontend stability release for the persistent Employer Post a Job loading mask.
It disables the legacy V49 full-screen route transition specifically on /post-job?employer=1 at three layers: early HTML guard, V49 source behavior, and V51/V53 runtime neutralizer.
It also carries forward the V52 Candidate Profile singleton/mobile fixes.
No backend, database, payment, Google Jobs, sitemap, Youth, social, service worker, or retention logic is changed.
The deployer accepts exact V51-FIXED2 or exact V52 frontend baseline and creates a private rollback backup.
