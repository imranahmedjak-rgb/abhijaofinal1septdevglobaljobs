#!/usr/bin/env bash
set -Eeuo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$HERE/payload"
fail(){ echo "FAIL: $*" >&2; exit 1; }
for c in sha256sum node grep find bash; do command -v "$c" >/dev/null 2>&1 || fail "Required command missing: $c"; done
cd "$HERE"
sha256sum -c PAYLOAD-SHA256SUMS.txt >/dev/null || fail "Payload checksum mismatch."
node --check "$PAYLOAD/dist/dgj-v45-commercial.cjs" >/dev/null || fail "V45 integration module syntax invalid."
node --check "$PAYLOAD/dist/dgj-v46-employer.cjs" >/dev/null || fail "Employer Workspace module syntax invalid."
node --check "$PAYLOAD/dist/dgj-v51-recruitment.cjs" >/dev/null || fail "Recruitment backend syntax invalid."
node --check "$PAYLOAD/dist/public/assets/dgj-v51-employer.js" >/dev/null || fail "Employer frontend syntax invalid."
node --check "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.js" >/dev/null || fail "Recruitment frontend syntax invalid."

grep -Fq "const RETENTION_DAYS=180" "$PAYLOAD/dist/dgj-v51-recruitment.cjs" || fail "180-day retention lock missing."
grep -Fq "application_method TEXT NOT NULL DEFAULT 'dgj'" "$PAYLOAD/dist/dgj-v51-recruitment.cjs" || fail "Easy Apply delivery schema missing."
grep -Fq "Applications delivered through Easy Apply via Email cannot be withdrawn" "$PAYLOAD/dist/dgj-v51-recruitment.cjs" || fail "Email Easy Apply no-withdraw rule missing."
grep -Fq "/api/v51/candidate/applications" "$PAYLOAD/dist/dgj-v51-recruitment.cjs" || fail "Candidate tracker API missing."
grep -Fq "/api/v51/employer/applications" "$PAYLOAD/dist/dgj-v51-recruitment.cjs" || fail "Employer Applications API missing."
grep -Fq "/api/v51/employer/jobs/:id/archive.zip" "$PAYLOAD/dist/dgj-v51-recruitment.cjs" || fail "Recruitment archive API missing."
grep -Fq "/api/v51/admin/recruitment.csv" "$PAYLOAD/dist/dgj-v51-recruitment.cjs" || fail "Admin recruitment export missing."
grep -Fq "pg_try_advisory_lock" "$PAYLOAD/dist/dgj-v51-recruitment.cjs" || fail "Lifecycle concurrency guard missing."
grep -Fq "client.release()" "$PAYLOAD/dist/dgj-v51-recruitment.cjs" || fail "Lifecycle lock connection release missing."
grep -Fq "Application deadline is required for employer recruitment" "$PAYLOAD/dist/dgj-v45-commercial.cjs" || fail "Required application deadline validation missing."
grep -Fq "applyEmail:null" "$PAYLOAD/dist/dgj-v45-commercial.cjs" || fail "Private application email architecture missing."
grep -Fq "applicationMethod" "$PAYLOAD/dist/dgj-v45-commercial.cjs" || fail "Employer Easy Apply method integration missing."
grep -Fq "recruitmentVersion:'51.0.0'" "$PAYLOAD/dist/dgj-v46-employer.cjs" || fail "Employer dashboard recruitment integration missing."
grep -Fq "Easy Apply via Dev Global Jobs" "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.js" || fail "DGJ Easy Apply choice missing."
grep -Fq "Easy Apply via Email" "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.js" || fail "Email Easy Apply choice missing."
grep -Fq "cannot be withdrawn through Dev Global Jobs" "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.js" || fail "Candidate Email-mode message missing."
grep -Fq "Application Tracker" "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.js" || fail "Candidate application tracker missing."
grep -Fq "Recruitment Centre" "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.js" || fail "Admin Recruitment Centre missing."
grep -Fq "Applications" "$PAYLOAD/dist/public/assets/dgj-v51-employer.js" || fail "Employer Applications navigation missing."
grep -Fq "Download Recruitment Archive" "$PAYLOAD/dist/public/assets/dgj-v51-employer.js" || fail "Employer archive download missing."
grep -Fq "overflow-y:auto!important" "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.css" || fail "Desktop Employer sidebar scroll fix missing."
grep -Fq "@media(display-mode:standalone)" "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.css" || fail "PWA safe-area rules missing."
! grep -Rqs "insertBefore" "$PAYLOAD/dist/public/assets/dgj-v51-employer.js" "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.js" || fail "Unsafe insertBefore remains in V51 frontend."
grep -Fq '/assets/dgj-v51-employer.js?v=51.0.0' "$PAYLOAD/dist/public/index.html" || fail "V51 Employer asset wiring missing."
grep -Fq '/assets/dgj-v51-recruitment.js?v=51.0.0' "$PAYLOAD/dist/public/index.html" || fail "V51 recruitment JS wiring missing."
grep -Fq '/assets/dgj-v51-recruitment.css?v=51.0.0' "$PAYLOAD/dist/public/index.html" || fail "V51 recruitment CSS wiring missing."
! grep -Fq 'easy-apply-v8.js' "$PAYLOAD/dist/public/index.html" || fail "Legacy Easy Apply JS is still active."
! grep -Fq 'easy-apply.css' "$PAYLOAD/dist/public/index.html" || fail "Legacy Easy Apply CSS is still active."
[ ! -f "$PAYLOAD/dist/index.cjs" ] || fail "V51 must not replace the main server runtime."
[ ! -f "$PAYLOAD/dist/public/assets/dgj-v45-commercial.js" ] || fail "V51 must not replace the proven V45 commercial UI."
[ ! -f "$PAYLOAD/dist/public/assets/dgj-v45-commercial.css" ] || fail "V51 must not replace the proven V45 commercial CSS."
[ ! -f "$PAYLOAD/dist/public/assets/dgj-v49-premium.js" ] || fail "V51 must not replace V49 premium JS."
[ ! -f "$PAYLOAD/dist/public/assets/dgj-v49-premium.css" ] || fail "V51 must not replace V49 premium CSS."
[ ! -f "$PAYLOAD/dist/public/assets/dgj-v46-employer.css" ] || fail "V51 must not replace V46 base Employer CSS."
! grep -Rqs "BEGIN PRIVATE KEY" "$PAYLOAD" || fail "Private key material detected."

# Offline route-registration smoke test with a non-persistent mock pool.
node - "$PAYLOAD/dist" <<'NODE'
const base=process.argv[2],routes=[];
const rec=m=>(...a)=>routes.push([m,a[0]]);
const app={get:rec('GET'),post:rec('POST'),put:rec('PUT'),delete:rec('DELETE'),patch:rec('PATCH'),use:()=>{}};
const mkclient=()=>({query:async(sql)=>String(sql).includes('pg_try_advisory_lock')?{rows:[{locked:false}],rowCount:1}:{rows:[],rowCount:0},release(){}});
const pool={query:async()=>({rows:[],rowCount:0}),connect:async()=>mkclient()};
const noop=()=>{};
(async()=>{
 await require(base+'/dgj-v45-commercial.cjs').install({app,pool,storage:{insertJob:async x=>({id:1,...x}),updateJobById:async()=>{}},requireAdmin:noop,classifyJobSkillCategory:()=> 'business',queueUrlForIndexing:noop,queueGoogleIndexingUpdate:noop,dgjRecordEmployerPosting:async()=>{},postJobSchema:{safeParse:x=>({success:true,data:x})},getVerificationMailer:()=>null});
 const v46=await require(base+'/dgj-v46-employer.cjs').install({app,pool,requireAdmin:noop,dgjUpsertContact:async()=>{},dgjEvent:async()=>{}});
 if(v46.recruitmentVersion!=='51.0.0') throw new Error('Recruitment module did not install.');
 const must=['/api/v51/jobs/:id/easy-apply','/api/v51/candidate/applications','/api/v51/employer/applications','/api/v51/employer/reports/applications.csv','/api/v51/employer/jobs/:id/archive.zip','/api/v51/admin/summary'];
 for(const p of must) if(!routes.some(r=>r[1]===p)) throw new Error('Missing route: '+p);
})().catch(e=>{console.error(e);process.exit(1)});
NODE

echo "PASS: V51 International Recruitment Platform offline preflight complete."
