Dev Global Jobs V51 — International Recruitment Platform
Date: 2026-09-01

Purpose
-------
This release turns Employer Easy Apply into a complete recruitment operating workflow while preserving the existing V45 commercial engine, V49 premium presentation and the protected Google Jobs / brand / sitemap architecture.

Single retention policy
-----------------------
Dev Global Jobs platform retention is locked to ONE duration: 180 days after recruitment closes. Job deadline expiry or an employer manual close starts the retention window. The employer receives a closure/download notice and reminders before automatic platform deletion. Copies already delivered to or downloaded by an employer remain the employer's responsibility.

Candidate experience
--------------------
- One public Easy Apply button only.
- Secure signed-in candidate application with private CV upload.
- Profile → My Applications tracker.
- Received → Under Review → Shortlisted → Interview → Offer → Hired / Not Selected.
- Easy Apply via DGJ can be withdrawn while eligible.
- Easy Apply via Email cannot be withdrawn through DGJ after delivery.
- Candidate can download the CV they submitted while it remains within retention.

Employer experience
-------------------
- Employer privately chooses Easy Apply via Dev Global Jobs or Easy Apply via Email.
- Recruitment email stays private and is not published in job data.
- Applications Inbox with job/status filtering.
- CV download and candidate application detail.
- Hiring status workflow and candidate status notifications.
- Applications count, conversion and hiring-funnel analytics.
- Aggregate demographics are shown only after at least 5 applications.
- Applicant CSV, performance CSV and complete per-job Recruitment Archive ZIP.
- Application settings per job and manual Close Recruitment.
- Independently scrollable desktop sidebar; Company Profile remains reachable.

Admin experience
----------------
- Recruitment Centre with platform application totals, pipeline and employer context.
- Authenticated admin CV access and recruitment CSV export.
- Existing Employer Accounts and V45 Promotion Centre stay in place.

Security / privacy controls
---------------------------
- Candidate CVs are written under /var/www/devglobaljobs/private/recruitment-applications, outside dist/public.
- PDF/DOC/DOCX content signatures are checked; max CV 5 MB.
- Candidate/employer/admin download APIs require authenticated ownership/role checks.
- Duplicate applications are blocked per candidate/job.
- Existing Easy Apply short-lived security token is consumed once.
- Email recruitment addresses are private application settings, not jobs.apply_email.
- Platform auto-purge removes identifiable V51 application records and private CV files after 180 days; aggregate job metrics remain.

Deployment safety
-----------------
- Supports exact successful V49 OR V50 baseline.
- Exact hashes are verified before mutation.
- Private rollback backup is created first.
- Main dist/index.cjs is NOT replaced.
- V45 commercial UI/CSS, V49 premium JS/CSS and V46 base CSS are NOT replaced.
- Protected Youth / Google Jobs / social / brand contract / service worker files are verified byte-for-byte after deployment.
- Database schema is additive only.
- Post-deploy route/security/origin/public health checks run automatically.
- Automatic file rollback occurs if a post-mutation validation fails.

Run
---
1. ./preflight-v51.sh
2. ./deploy-v51-recruitment-safe.sh
