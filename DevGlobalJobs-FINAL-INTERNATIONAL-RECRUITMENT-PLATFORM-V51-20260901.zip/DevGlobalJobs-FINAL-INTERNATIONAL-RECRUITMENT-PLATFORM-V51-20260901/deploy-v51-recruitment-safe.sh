#!/usr/bin/env bash
set -Eeuo pipefail
APP="/var/www/devglobaljobs"
DIST="$APP/dist"
PUBLIC="$DIST/public"
ASSETS="$PUBLIC/assets"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/var/backups/devglobaljobs-recruitment-v51-${STAMP}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$HERE/payload"

# Exact recognized production baselines: successful V49 or V50 hotfix.
BASE_SERVER_SHA="754afef80c982fd75e6373d839893858a85f42909589da5ffd29d59c2fdbcd0c"
BASE_V49_INDEX_SHA="f7fcf7953928bbc1573c1ae471692898230b86b2ca07da72b89f3e9344ad5a5f"
BASE_V50_INDEX_SHA="dc73837bcd2809ba037e45aa70856e2464c79d6d77ef6821af3277269470ce05"
BASE_V46_MODULE_SHA="43830d9aa2887ba7d9e136a84b31dc3ca915d722124ff7c160dd29139ce0c75b"
BASE_V49_EMPLOYER_UI_SHA="e206733dee07e3ce73e5457e39d110a532520d56e38ebfd59dc879c7a514c715"
BASE_V50_EMPLOYER_UI_SHA="3435db7bc5f11069a66484a4d71a87816aa045f507f3f885d7d538ca7ea5ace5"
BASE_V49_JS_SHA="d7a9fff8892ac44e9f38a72fab121550d03ea3d9fc3557c29db251c1fdd3492f"
BASE_V49_CSS_SHA="5929d5a9edb36e5670dadf0511508e945751b510dbb20fead09116f5e1c41e2f"
BASE_V45_MODULE_SHA="d8ba3950fc169dfaa94fa061b466dd3152bc969a375b6e31ed87f7155af09b0f"
BASE_V45_UI_SHA="a52126b670737e30dd6f929fb6f901d2e66bf99f899d65a22199ce3e0952a801"
BASE_V45_CSS_SHA="cd3038190e9fc212058fd53bdf506b6bd28661764fdb083605e589d54819dfe7"
BASE_V46_CSS_SHA="d541842ee81e1b7e9256a32bff9654709d1ff6c78edae7fb2c91a9762a195b9c"
BASE_YOUTH_SHA="ff420f2b6b88f06f5a9f6c9e3bc2ae88b456bbca5bb6a76b3047992874a909df"
BASE_GOOGLE_JOBS_SHA="efd02864b5ea0703465ab7d62a6b8dc43d7a48e0ea074082a45f6a7adc23ddf6"
BASE_SOCIAL_SHA="528878c345ddf89bde59041513d2b406fb1c8bcb786ee9874413247a6a6cbd92"
BASE_CONTRACT_SHA="00e06a8e7592a5aff18fcfa21492b43a2ad513c46a473d45f45367c7765295b4"
BASE_SW_SHA="7f6986e064891c43437df7f35fd4c2a7050d1ce82bd0120b12afb7e9fa1733f3"

NEW_V45_SHA="604bc9cdc6f60ec989bf9582558dbe5b470018e3e1ffb631a9866763d8859dfe"
NEW_V46_SHA="bc5c4f4088cc434aabe5acfba0c9b521228330775799c55c2e941a95f05b205e"
NEW_V51_BACKEND_SHA="904fa113528a1cde41dcaade4bbca5dc40083390f1e800bc490279f211e6235e"
NEW_EMPLOYER_JS_SHA="dba27db99edc578ffeea08efb29edfea8af3b194edf6a4d130d150f0aa971ef6"
NEW_RECRUITMENT_CSS_SHA="7392d2c6f73cc67d3d9c2cb8a93b5a5c0a4f923438bd56bd0967855d4bc3b0f0"
NEW_RECRUITMENT_JS_SHA="f59c3d0b8096dcf2ec6921e395151e7f16ff8c1e6fe8c4dae15b22d6fa98b766"
NEW_INDEX_SHA="335ed46c93b624e0ad2558de7683e91e64f564259838685147ef9f3f65b233b7"

MUTATED=0
BASELINE=""
sha(){ sha256sum "$1" | awk '{print $1}'; }
fail(){ echo; echo "============================================================"; echo "SAFE STOP: $*"; echo "NOTHING UNVERIFIED WILL BE DEPLOYED."; echo "============================================================"; exit 1; }
backup_one(){ local src="$1" name="$2"; if [ -f "$src" ]; then cp -af "$src" "$BACKUP/$name"; else : > "$BACKUP/$name.__MISSING__"; fi; }
restore_one(){ local dst="$1" name="$2"; if [ -f "$BACKUP/$name.__MISSING__" ]; then rm -f "$dst"; elif [ -f "$BACKUP/$name" ]; then cp -af "$BACKUP/$name" "$dst"; fi; }
rollback(){
  local rc=$?
  if [ "$MUTATED" = "1" ]; then
    echo; echo "ROLLBACK: restoring exact pre-V51 files..."; set +e
    restore_one "$DIST/dgj-v45-commercial.cjs" dgj-v45-commercial.cjs
    restore_one "$DIST/dgj-v46-employer.cjs" dgj-v46-employer.cjs
    restore_one "$DIST/dgj-v51-recruitment.cjs" dgj-v51-recruitment.cjs
    restore_one "$ASSETS/dgj-v51-employer.js" dgj-v51-employer.js
    restore_one "$ASSETS/dgj-v51-recruitment.js" dgj-v51-recruitment.js
    restore_one "$ASSETS/dgj-v51-recruitment.css" dgj-v51-recruitment.css
    restore_one "$PUBLIC/index.html" index.html
    pm2 reload devglobaljobs --update-env >/dev/null 2>&1 || true
    echo "ROLLBACK COMPLETE. Additive V51 database tables/columns may remain but are dormant under the restored runtime."
    set -e
  fi
  exit "$rc"
}
trap rollback ERR INT TERM

cat <<'BANNER'
============================================================
DEV GLOBAL JOBS V51
INTERNATIONAL RECRUITMENT PLATFORM
ONE EASY APPLY · EMPLOYER DELIVERY CHOICE · ATS · REPORTS
180-DAY SINGLE DATA RETENTION POLICY
============================================================
BANNER

[ "$(id -u)" = "0" ] || fail "Run as root."
for c in sha256sum node curl install grep mkdir cp mv chmod find pm2 seq sleep awk id bash; do command -v "$c" >/dev/null 2>&1 || fail "Required command missing: $c"; done
[ -d "$ASSETS" ] || fail "Public assets directory missing."

 echo; echo "1/9 EXACT V49/V50 BASELINE + LIVE HEALTH"
[ -f "$DIST/index.cjs" ] || fail "Main server runtime missing."
[ "$(sha "$DIST/index.cjs")" = "$BASE_SERVER_SHA" ] || fail "Main server is not the recognized successful V49/V50 runtime."
IDX_SHA="$(sha "$PUBLIC/index.html")"
if [ "$IDX_SHA" = "$BASE_V50_INDEX_SHA" ]; then
  BASELINE="V50"
  [ -f "$ASSETS/dgj-v50-employer.js" ] || fail "V50 Employer hotfix asset missing."
  [ "$(sha "$ASSETS/dgj-v50-employer.js")" = "$BASE_V50_EMPLOYER_UI_SHA" ] || fail "V50 Employer hotfix asset changed."
elif [ "$IDX_SHA" = "$BASE_V49_INDEX_SHA" ]; then
  BASELINE="V49"
  [ -f "$ASSETS/dgj-v46-employer.js" ] || fail "V49 Employer UI asset missing."
  [ "$(sha "$ASSETS/dgj-v46-employer.js")" = "$BASE_V49_EMPLOYER_UI_SHA" ] || fail "V49 Employer UI asset changed."
else
  fail "Public index is not exact successful V49 or V50 baseline."
fi
[ "$(sha "$DIST/dgj-v45-commercial.cjs")" = "$BASE_V45_MODULE_SHA" ] || fail "V45 commercial backend baseline changed."
[ "$(sha "$DIST/dgj-v46-employer.cjs")" = "$BASE_V46_MODULE_SHA" ] || fail "Employer backend baseline changed."
[ "$(sha "$ASSETS/dgj-v49-premium.js")" = "$BASE_V49_JS_SHA" ] || fail "V49 premium JS changed."
[ "$(sha "$ASSETS/dgj-v49-premium.css")" = "$BASE_V49_CSS_SHA" ] || fail "V49 premium CSS changed."
curl -fsS --max-time 20 http://127.0.0.1:8080/api/jobs/stats >/dev/null || fail "Local application health failed."
echo "PASS: exact $BASELINE production baseline verified."

 echo; echo "2/9 V51 PACKAGE + OFFLINE PREFLIGHT"
sha256sum -c "$HERE/PAYLOAD-SHA256SUMS.txt" >/dev/null || fail "Payload checksum failed."
bash "$HERE/preflight-v51.sh" || fail "V51 offline preflight failed."
echo "PASS: V51 package integrity and recruitment architecture verified."

 echo; echo "3/9 PROTECTED COMMERCIAL / SEO / BRAND CONTRACT"
[ ! -f "$PAYLOAD/dist/index.cjs" ] || fail "V51 must not replace main server runtime."
[ ! -f "$PAYLOAD/dist/public/assets/dgj-v45-commercial.js" ] || fail "V51 must not replace V45 commercial UI."
[ ! -f "$PAYLOAD/dist/public/assets/dgj-v49-premium.js" ] || fail "V51 must not replace V49 premium UI."
[ ! -f "$PAYLOAD/dist/public/assets/dgj-v46-employer.css" ] || fail "V51 must not replace V46 base CSS."
echo "PASS: main server, V45 commercial UI, V49 premium UI and protected SEO assets are outside the payload."

 echo; echo "4/9 PRIVATE ROLLBACK BACKUP"
mkdir -p "$BACKUP"; chmod 700 "$BACKUP"
backup_one "$DIST/dgj-v45-commercial.cjs" dgj-v45-commercial.cjs
backup_one "$DIST/dgj-v46-employer.cjs" dgj-v46-employer.cjs
backup_one "$DIST/dgj-v51-recruitment.cjs" dgj-v51-recruitment.cjs
backup_one "$ASSETS/dgj-v51-employer.js" dgj-v51-employer.js
backup_one "$ASSETS/dgj-v51-recruitment.js" dgj-v51-recruitment.js
backup_one "$ASSETS/dgj-v51-recruitment.css" dgj-v51-recruitment.css
backup_one "$PUBLIC/index.html" index.html
printf '%s\n' "$BASELINE" > "$BACKUP/baseline.txt"
chmod -R go-rwx "$BACKUP"
echo "Backup: $BACKUP"
echo "PASS: rollback files stored privately."

 echo; echo "5/9 ATOMIC V51 INSTALL"
install_atomic(){ local src="$1" dst="$2" mode="${3:-0644}" tmp="${dst}.v51.$$"; install -m "$mode" "$src" "$tmp"; mv -f "$tmp" "$dst"; }
install_atomic "$PAYLOAD/dist/dgj-v45-commercial.cjs" "$DIST/dgj-v45-commercial.cjs"
install_atomic "$PAYLOAD/dist/dgj-v46-employer.cjs" "$DIST/dgj-v46-employer.cjs"
install_atomic "$PAYLOAD/dist/dgj-v51-recruitment.cjs" "$DIST/dgj-v51-recruitment.cjs"
install_atomic "$PAYLOAD/dist/public/assets/dgj-v51-employer.js" "$ASSETS/dgj-v51-employer.js"
install_atomic "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.js" "$ASSETS/dgj-v51-recruitment.js"
install_atomic "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.css" "$ASSETS/dgj-v51-recruitment.css"
install_atomic "$PAYLOAD/dist/public/index.html" "$PUBLIC/index.html"
MUTATED=1
[ "$(sha "$DIST/dgj-v45-commercial.cjs")" = "$NEW_V45_SHA" ] || false
[ "$(sha "$DIST/dgj-v46-employer.cjs")" = "$NEW_V46_SHA" ] || false
[ "$(sha "$DIST/dgj-v51-recruitment.cjs")" = "$NEW_V51_BACKEND_SHA" ] || false
[ "$(sha "$ASSETS/dgj-v51-employer.js")" = "$NEW_EMPLOYER_JS_SHA" ] || false
[ "$(sha "$ASSETS/dgj-v51-recruitment.js")" = "$NEW_RECRUITMENT_JS_SHA" ] || false
[ "$(sha "$ASSETS/dgj-v51-recruitment.css")" = "$NEW_RECRUITMENT_CSS_SHA" ] || false
[ "$(sha "$PUBLIC/index.html")" = "$NEW_INDEX_SHA" ] || false
echo "PASS: reviewed V51 modules, frontend assets and index installed."

 echo; echo "6/9 PM2 RELOAD + V51 ROUTE SECURITY"
pm2 reload devglobaljobs --update-env
READY=0
for i in $(seq 1 30); do
  if curl -fsS --max-time 8 http://127.0.0.1:8080/api/jobs/stats >/dev/null 2>&1; then READY=1; echo "PASS: application ready after reload (attempt $i/30)."; break; fi
  sleep 2
done
[ "$READY" = "1" ] || false
CFG="$BACKUP/v51-config.json"; curl -fsS --max-time 20 http://127.0.0.1:8080/api/v51/config -o "$CFG" || false
node - "$CFG" <<'NODE'
const fs=require('fs'),x=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));if(x.version!=='51.0.0'||Number(x.retentionDays)!==180||!Array.isArray(x.applicationMethods)||!x.applicationMethods.includes('dgj')||!x.applicationMethods.includes('email'))process.exit(1);
NODE
CAND_CODE="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 20 http://127.0.0.1:8080/api/v51/candidate/applications || true)"
EMP_CODE="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 20 http://127.0.0.1:8080/api/v51/employer/applications || true)"
[ "$CAND_CODE" = "401" ] || { echo "FAIL: unauth candidate applications returned $CAND_CODE"; false; }
[ "$EMP_CODE" = "401" ] || { echo "FAIL: unauth employer applications returned $EMP_CODE"; false; }
[ -d "$APP/private/recruitment-applications" ] || { echo "FAIL: private recruitment storage directory missing."; false; }
chmod 700 "$APP/private/recruitment-applications" || false
echo "PASS: V51 config, 180-day policy, protected Candidate/Employer APIs and private CV storage verified."

 echo; echo "7/9 EMPLOYER / POST-JOB / PUBLIC ASSET CONTRACT"
curl -fsS --max-time 20 "http://127.0.0.1:8080/assets/dgj-v51-employer.js?v=51.0.0" >/dev/null || false
curl -fsS --max-time 20 "http://127.0.0.1:8080/assets/dgj-v51-recruitment.js?v=51.0.0" >/dev/null || false
curl -fsS --max-time 20 "http://127.0.0.1:8080/assets/dgj-v51-recruitment.css?v=51.0.0" >/dev/null || false
curl -fsS --max-time 20 http://127.0.0.1:8080/ | grep -Fq 'dgj-v51-recruitment.js?v=51.0.0' || false
POST_FILE="$BACKUP/v51-post-signin.html"; POST_CODE="$(curl -sS -o "$POST_FILE" -w '%{http_code}' --max-time 20 http://127.0.0.1:8080/post-job || true)"; [ "$POST_CODE" = "200" ] || { echo "FAIL: signed-out /post-job returned $POST_CODE"; false; }; grep -Fq 'Dev Global Jobs for Employers' "$POST_FILE" || false
EMP_FILE="$BACKUP/v51-employer-entry.html"; EMP_CODE2="$(curl -sS -L -o "$EMP_FILE" -w '%{http_code}' --max-time 20 http://127.0.0.1:8080/employer || true)"; [ "$EMP_CODE2" = "200" ] || { echo "FAIL: signed-out /employer flow returned $EMP_CODE2"; false; }; grep -Fq 'Dev Global Jobs for Employers' "$EMP_FILE" || false
echo "PASS: Employer Sign In, Post a Job journey and V51 assets are served correctly."

 echo; echo "8/9 BYTE-FOR-BYTE PROTECTED FILE CHECK"
[ "$(sha "$DIST/index.cjs")" = "$BASE_SERVER_SHA" ] || false
[ "$(sha "$ASSETS/dgj-v45-commercial.js")" = "$BASE_V45_UI_SHA" ] || false
[ "$(sha "$ASSETS/dgj-v45-commercial.css")" = "$BASE_V45_CSS_SHA" ] || false
[ "$(sha "$ASSETS/dgj-v46-employer.css")" = "$BASE_V46_CSS_SHA" ] || false
[ "$(sha "$ASSETS/dgj-v49-premium.js")" = "$BASE_V49_JS_SHA" ] || false
[ "$(sha "$ASSETS/dgj-v49-premium.css")" = "$BASE_V49_CSS_SHA" ] || false
[ "$(sha "$ASSETS/index-DGJ45auth-v43-youth.js")" = "$BASE_YOUTH_SHA" ] || false
[ "$(sha "$PUBLIC/dgj-google-jobs-v27.js")" = "$BASE_GOOGLE_JOBS_SHA" ] || false
[ "$(sha "$PUBLIC/devglobaljobs-social-share.png")" = "$BASE_SOCIAL_SHA" ] || false
[ "$(sha "$PUBLIC/brand-contract.json")" = "$BASE_CONTRACT_SHA" ] || false
[ "$(sha "$PUBLIC/sw.js")" = "$BASE_SW_SHA" ] || false
echo "PASS: main runtime, paid UI, premium UI, Youth, Google Jobs, social, brand contract and service worker unchanged."

 echo; echo "9/9 FINAL ORIGIN + PUBLIC HEALTH"
curl -fsS --max-time 20 http://127.0.0.1:8080/api/jobs/stats >/dev/null || false
curl -fsS --max-time 25 https://devglobaljobs.com/ >/dev/null || false
curl -fsS --max-time 25 https://devglobaljobs.com/sitemap-index.xml >/dev/null || false

echo; echo "============================================================"
echo "SUCCESS: V51 INTERNATIONAL RECRUITMENT PLATFORM IS LIVE"
echo "============================================================"
echo "✓ Candidate sees one Easy Apply button"
echo "✓ Employer privately selects Easy Apply via DGJ or Email"
echo "✓ Email-delivered Easy Apply has no DGJ withdrawal option"
echo "✓ Candidate Profile includes My Applications progress tracking"
echo "✓ Employer Applications Inbox, hiring pipeline and CV download are active"
echo "✓ Job recruitment archive ZIP + applicant/performance CSV exports are active"
echo "✓ Employer analytics adds Applications, conversion, hiring funnel and protected aggregate demographics"
echo "✓ Admin Recruitment Centre + platform recruitment export are active"
echo "✓ Employer sidebar independently scrolls to Company Profile"
echo "✓ Application Deadline is required for new employer recruitment jobs"
echo "✓ One global DGJ retention duration: 180 days after recruitment closes"
echo "✓ Job deadline/manual closure triggers employer record-download notice and deletion reminders"
echo "✓ Identifiable DGJ applications/CVs auto-purge after retention; aggregate metrics remain"
echo "✓ Private CV storage is outside public web root"
echo "✓ V45 posting/payments/receipts/Boost/plan codes and V49 premium presentation preserved"
echo "✓ Main runtime / Google Jobs / sitemap / Youth / social / service worker / brand contract preserved"
echo "Rollback backup: $BACKUP"
echo "NOTE: V51 schema is additive; rollback restores files but leaves dormant additive V51 tables."
echo "============================================================"
trap - ERR INT TERM
