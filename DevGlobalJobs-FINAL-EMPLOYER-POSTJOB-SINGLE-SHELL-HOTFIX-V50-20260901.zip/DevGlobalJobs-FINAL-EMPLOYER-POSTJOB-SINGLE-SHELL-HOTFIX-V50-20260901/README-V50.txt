Dev Global Jobs V50
Employer Post a Job single-shell production hotfix.

This package is intentionally narrow. It fixes the duplicate Employer Workspace shell regression introduced by the V49 Post a Job DOM-race change without rolling back the V49 premium Employer/Admin improvements.

Deploy only on the exact successful V49 baseline using deploy-v50-single-shell-safe.sh.
