#!/usr/bin/env bash
set -Eeuo pipefail
APP="/var/www/devglobaljobs"
DIST="$APP/dist"
PUBLIC="$DIST/public"
ASSETS="$PUBLIC/assets"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/var/backups/devglobaljobs-employer-v50-${STAMP}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$HERE/payload"

# Exact successful V49 live baseline.
BASE_SERVER_SHA="754afef80c982fd75e6373d839893858a85f42909589da5ffd29d59c2fdbcd0c"
BASE_INDEX_SHA="f7fcf7953928bbc1573c1ae471692898230b86b2ca07da72b89f3e9344ad5a5f"
BASE_V46_MODULE_SHA="43830d9aa2887ba7d9e136a84b31dc3ca915d722124ff7c160dd29139ce0c75b"
BASE_V49_EMPLOYER_UI_SHA="e206733dee07e3ce73e5457e39d110a532520d56e38ebfd59dc879c7a514c715"
BASE_V49_JS_SHA="d7a9fff8892ac44e9f38a72fab121550d03ea3d9fc3557c29db251c1fdd3492f"
BASE_V49_CSS_SHA="5929d5a9edb36e5670dadf0511508e945751b510dbb20fead09116f5e1c41e2f"
BASE_V45_MODULE_SHA="d8ba3950fc169dfaa94fa061b466dd3152bc969a375b6e31ed87f7155af09b0f"
BASE_V45_UI_SHA="a52126b670737e30dd6f929fb6f901d2e66bf99f899d65a22199ce3e0952a801"
BASE_V45_CSS_SHA="cd3038190e9fc212058fd53bdf506b6bd28661764fdb083605e589d54819dfe7"
BASE_MAIN_SHA="ff420f2b6b88f06f5a9f6c9e3bc2ae88b456bbca5bb6a76b3047992874a909df"
BASE_GOOGLE_JOBS_SHA="efd02864b5ea0703465ab7d62a6b8dc43d7a48e0ea074082a45f6a7adc23ddf6"
BASE_SOCIAL_SHA="528878c345ddf89bde59041513d2b406fb1c8bcb786ee9874413247a6a6cbd92"
BASE_CONTRACT_SHA="00e06a8e7592a5aff18fcfa21492b43a2ad513c46a473d45f45367c7765295b4"
BASE_SW_SHA="7f6986e064891c43437df7f35fd4c2a7050d1ce82bd0120b12afb7e9fa1733f3"

NEW_V50_UI_SHA="3435db7bc5f11069a66484a4d71a87816aa045f507f3f885d7d538ca7ea5ace5"
NEW_INDEX_SHA="dc73837bcd2809ba037e45aa70856e2464c79d6d77ef6821af3277269470ce05"

MUTATED=0
sha(){ sha256sum "$1" | awk '{print $1}'; }
fail(){ echo; echo "============================================================"; echo "SAFE STOP: $*"; echo "NOTHING UNVERIFIED WILL BE KEPT."; echo "============================================================"; exit 1; }
rollback(){
  local rc=$?
  if [ "$MUTATED" = "1" ]; then
    echo; echo "ROLLBACK: restoring exact pre-V50 V49 public index..."; set +e
    [ -f "$BACKUP/index.html" ] && cp -af "$BACKUP/index.html" "$PUBLIC/index.html"
    if [ -f "$BACKUP/dgj-v50-employer.js" ]; then cp -af "$BACKUP/dgj-v50-employer.js" "$ASSETS/dgj-v50-employer.js"; else rm -f "$ASSETS/dgj-v50-employer.js"; fi
    echo "ROLLBACK COMPLETE. V49 runtime and Employer/Admin premium system remain unchanged."
    set -e
  fi
  exit "$rc"
}
trap rollback ERR INT TERM

echo "============================================================"
echo "DEV GLOBAL JOBS V50"
echo "EMPLOYER POST A JOB SINGLE-SHELL HOTFIX"
echo "NO COMMERCIAL / DATABASE / SEO CHANGES"
echo "============================================================"
[ "$(id -u)" = "0" ] || fail "Run as root."
for c in sha256sum node curl install grep mkdir cp mv chmod find; do command -v "$c" >/dev/null 2>&1 || fail "Required command missing: $c"; done
[ -d "$ASSETS" ] || fail "Public assets directory missing."

echo; echo "1/8 EXACT SUCCESSFUL V49 BASELINE + HEALTH"
[ "$(sha "$DIST/index.cjs")" = "$BASE_SERVER_SHA" ] || fail "Main server is not exact V49 baseline."
[ "$(sha "$PUBLIC/index.html")" = "$BASE_INDEX_SHA" ] || fail "Public index is not exact successful V49 baseline."
[ "$(sha "$DIST/dgj-v46-employer.cjs")" = "$BASE_V46_MODULE_SHA" ] || fail "V49 employer backend changed."
[ "$(sha "$ASSETS/dgj-v46-employer.js")" = "$BASE_V49_EMPLOYER_UI_SHA" ] || fail "V49 Employer UI baseline changed."
[ "$(sha "$ASSETS/dgj-v49-premium.js")" = "$BASE_V49_JS_SHA" ] || fail "V49 premium JS changed."
[ "$(sha "$ASSETS/dgj-v49-premium.css")" = "$BASE_V49_CSS_SHA" ] || fail "V49 premium CSS changed."
curl -fsS --max-time 20 http://127.0.0.1:8080/api/jobs/stats >/dev/null || fail "Local application health failed."
echo "PASS: exact successful V49 baseline verified."

echo; echo "2/8 V50 SINGLE-SHELL PAYLOAD VALIDATION"
sha256sum -c "$HERE/PAYLOAD-SHA256SUMS.txt" >/dev/null || fail "Payload checksum failed."
node --check "$PAYLOAD/dist/public/assets/dgj-v50-employer.js" >/dev/null || fail "V50 Employer JS syntax invalid."
grep -Fq "postShellBusy=false" "$PAYLOAD/dist/public/assets/dgj-v50-employer.js" || fail "Synchronous Post a Job lock missing."
grep -Fq "if(postShellBusy||\$('#dgj46-post-shell'))return" "$PAYLOAD/dist/public/assets/dgj-v50-employer.js" || fail "Pre-await shell lock missing."
grep -Fq "cleanupPostShells" "$PAYLOAD/dist/public/assets/dgj-v50-employer.js" || fail "Defensive duplicate cleanup missing."
grep -Fq '/assets/dgj-v50-employer.js?v=50.0.0' "$PAYLOAD/dist/public/index.html" || fail "Fresh V50 Employer asset URL missing."
echo "PASS: single-shell concurrency lock + duplicate cleanup + fresh asset URL verified."

echo; echo "3/8 PROTECTED V49 / V45 / SEO CHECK"
[ ! -f "$PAYLOAD/dist/index.cjs" ] || fail "V50 must not package main server runtime."
[ ! -f "$PAYLOAD/dist/dgj-v46-employer.cjs" ] || fail "V50 must not replace V49 employer backend."
[ ! -f "$PAYLOAD/dist/public/assets/dgj-v49-premium.js" ] || fail "V50 must not replace V49 premium JS."
[ ! -f "$PAYLOAD/dist/public/assets/dgj-v49-premium.css" ] || fail "V50 must not replace V49 premium CSS."
echo "PASS: V50 is a narrow Post a Job UI hotfix only."

echo; echo "4/8 PRIVATE ROLLBACK BACKUP"
mkdir -p "$BACKUP"; chmod 700 "$BACKUP"
cp -af "$PUBLIC/index.html" "$BACKUP/index.html"
[ -f "$ASSETS/dgj-v50-employer.js" ] && cp -af "$ASSETS/dgj-v50-employer.js" "$BACKUP/dgj-v50-employer.js" || true
chmod -R go-rwx "$BACKUP"
echo "Backup: $BACKUP"
echo "PASS: private rollback backup created."

echo; echo "5/8 ATOMIC V50 INSTALL"
tmp_ui="$ASSETS/.dgj-v50-employer.js.$$"; tmp_index="$PUBLIC/.index.html.v50.$$"
install -m 0644 "$PAYLOAD/dist/public/assets/dgj-v50-employer.js" "$tmp_ui"
install -m 0644 "$PAYLOAD/dist/public/index.html" "$tmp_index"
mv -f "$tmp_ui" "$ASSETS/dgj-v50-employer.js"
mv -f "$tmp_index" "$PUBLIC/index.html"
MUTATED=1
[ "$(sha "$ASSETS/dgj-v50-employer.js")" = "$NEW_V50_UI_SHA" ] || false
[ "$(sha "$PUBLIC/index.html")" = "$NEW_INDEX_SHA" ] || false
echo "PASS: fresh V50 Employer UI asset and public index installed. No PM2/backend change required."

echo; echo "6/8 ORIGIN ROUTE + FRESH ASSET TESTS"
curl -fsS --max-time 20 http://127.0.0.1:8080/assets/dgj-v50-employer.js?v=50.0.0 >/dev/null || false
curl -fsS --max-time 20 http://127.0.0.1:8080/ | grep -Fq 'dgj-v50-employer.js?v=50.0.0' || false
POST_FILE="$BACKUP/v50-post-signin.html"; POST_CODE="$(curl -sS -o "$POST_FILE" -w '%{http_code}' --max-time 20 http://127.0.0.1:8080/post-job || true)"; [ "$POST_CODE" = "200" ] || { echo "FAIL: signed-out /post-job returned $POST_CODE."; false; }; grep -Fq 'Dev Global Jobs for Employers' "$POST_FILE" || { echo "FAIL: Employer Sign In branding missing."; false; }
echo "PASS: fresh asset served and signed-out Post a Job route remains professional Employer Sign In."

echo; echo "7/8 BYTE-FOR-BYTE PROTECTED FILE CHECK"
[ "$(sha "$DIST/index.cjs")" = "$BASE_SERVER_SHA" ] || false
[ "$(sha "$DIST/dgj-v46-employer.cjs")" = "$BASE_V46_MODULE_SHA" ] || false
[ "$(sha "$ASSETS/dgj-v46-employer.js")" = "$BASE_V49_EMPLOYER_UI_SHA" ] || false
[ "$(sha "$ASSETS/dgj-v49-premium.js")" = "$BASE_V49_JS_SHA" ] || false
[ "$(sha "$ASSETS/dgj-v49-premium.css")" = "$BASE_V49_CSS_SHA" ] || false
[ "$(sha "$DIST/dgj-v45-commercial.cjs")" = "$BASE_V45_MODULE_SHA" ] || false
[ "$(sha "$ASSETS/dgj-v45-commercial.js")" = "$BASE_V45_UI_SHA" ] || false
[ "$(sha "$ASSETS/dgj-v45-commercial.css")" = "$BASE_V45_CSS_SHA" ] || false
[ "$(sha "$ASSETS/index-DGJ45auth-v43-youth.js")" = "$BASE_MAIN_SHA" ] || false
[ "$(sha "$PUBLIC/dgj-google-jobs-v27.js")" = "$BASE_GOOGLE_JOBS_SHA" ] || false
[ "$(sha "$PUBLIC/devglobaljobs-social-share.png")" = "$BASE_SOCIAL_SHA" ] || false
[ "$(sha "$PUBLIC/brand-contract.json")" = "$BASE_CONTRACT_SHA" ] || false
[ "$(sha "$PUBLIC/sw.js")" = "$BASE_SW_SHA" ] || false
echo "PASS: V49 premium, V45 commercial, Employer backend and protected SEO files unchanged."

echo; echo "8/8 FINAL HEALTH"
curl -fsS --max-time 20 http://127.0.0.1:8080/api/jobs/stats >/dev/null || false
curl -fsS --max-time 20 https://devglobaljobs.com/ >/dev/null || false

echo; echo "============================================================"
echo "SUCCESS: V50 EMPLOYER POST A JOB SINGLE-SHELL HOTFIX IS LIVE"
echo "============================================================"
echo "✓ Duplicate Employer Workspace shell race fixed before async employer lookup"
echo "✓ Existing shell re-checked after async lookup"
echo "✓ Defensive duplicate shell cleanup included"
echo "✓ Fresh cache-busted Employer UI asset forces corrected browser code"
echo "✓ V49 premium Employer/Admin visual upgrades retained"
echo "✓ V49 company logo feature retained"
echo "✓ V45 payments / Boost / receipts / emails / plans / quotas unchanged"
echo "✓ Main server / database / Google Jobs / sitemap / Youth / social / service worker unchanged"
echo "Rollback backup: $BACKUP"
echo "============================================================"
trap - ERR INT TERM
