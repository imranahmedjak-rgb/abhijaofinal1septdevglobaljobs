#!/usr/bin/env bash
set -Eeuo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$HERE/payload"
sha256sum -c "$HERE/PAYLOAD-SHA256SUMS.txt" >/dev/null
node --check "$PAYLOAD/dist/public/assets/dgj-v50-employer.js" >/dev/null
grep -Fq "postShellBusy=false" "$PAYLOAD/dist/public/assets/dgj-v50-employer.js"
grep -Fq "if(postShellBusy||\$('#dgj46-post-shell'))return" "$PAYLOAD/dist/public/assets/dgj-v50-employer.js"
grep -Fq "cleanupPostShells" "$PAYLOAD/dist/public/assets/dgj-v50-employer.js"
grep -Fq "if(\$('#dgj46-post-shell'))return" "$PAYLOAD/dist/public/assets/dgj-v50-employer.js"
if grep -Fq 'document.body.insertBefore(shell,root)' "$PAYLOAD/dist/public/assets/dgj-v50-employer.js"; then
  echo "FAIL: legacy unsafe shell insertion detected."
  exit 1
fi
grep -Fq '/assets/dgj-v50-employer.js?v=50.0.0' "$PAYLOAD/dist/public/index.html"
if grep -Fq '/assets/dgj-v46-employer.js?v=46.1.0' "$PAYLOAD/dist/public/index.html"; then
  echo "FAIL: old cacheable Employer UI asset still referenced."
  exit 1
fi
echo "PASS: V50 single-shell lock, duplicate cleanup, cache-busted Employer asset and narrow scope verified."
