#!/usr/bin/env bash
set -Eeuo pipefail
BASE="$(cd "$(dirname "$0")" && pwd)"
P="$BASE/payload/dist/public"
node --check "$P/assets/dgj-v49-premium.js" >/dev/null
node --check "$P/assets/dgj-v51-recruitment.js" >/dev/null
grep -Fq 'dgj-v54-post-route-guard' "$P/index.html"
grep -Fq "html.dgj54-employer-post #dgj49-route-transition,html.dgj54-employer-post #dgj-splash" "$P/index.html"
grep -Fq "new URLSearchParams(q).get('employer')==='1') return;" "$P/index.html"
grep -Fq "var immediateSplash = document.getElementById('dgj-splash');" "$P/index.html"
grep -Fq "const s=\$('#dgj-splash');if(s)s.remove();" "$P/assets/dgj-v51-recruitment.js"
grep -Fq 'window.__DGJ_V54_AUTH_POST_STABILITY__=true' "$P/assets/dgj-v51-recruitment.js"
grep -Fq '/assets/dgj-v49-premium.js?v=54.0.0' "$P/index.html"
grep -Fq '/assets/dgj-v51-recruitment.js?v=54.0.0' "$P/index.html"
grep -Fq '/assets/dgj-v51-recruitment.css?v=54.0.0' "$P/index.html"
# Preserve V52 singleton profile fix and V53 dark-loader guard.
grep -Fq 'cleanupCandidateApplicationDuplicates' "$P/assets/dgj-v51-recruitment.js"
grep -Fq 'neutralizeLegacyEmployerPostTransition' "$P/assets/dgj-v51-recruitment.js"
# The old employer post bridge must not self-navigate before the V54 query guard.
python3 - "$P/index.html" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text()
bridge=s[s.index('<script id="dgj-auth-route-bridge">'):s.index('</script>',s.index('<script id="dgj-auth-route-bridge">'))]
skip="if(p==='/post-job' && new URLSearchParams(q).get('employer')==='1') return;"
branch="if(p==='/sign-in' || p==='/post-job')"
assert skip in bridge and branch in bridge and bridge.index(skip)<bridge.index(branch)
assert ".catch(function(){location.assign(p);});" not in bridge
assert "location.assign(p+q);" in bridge
# Splash guard must be present before the branded splash DOM element.
assert s.index('dgj-v54-post-route-guard') < s.index('id="dgj-splash"')
print('PASS: V54 employer auth/post route bridge and branded-splash guards verified.')
PY
echo 'PASS: V54 Employer Auth + Post Job Stability offline preflight complete.'
