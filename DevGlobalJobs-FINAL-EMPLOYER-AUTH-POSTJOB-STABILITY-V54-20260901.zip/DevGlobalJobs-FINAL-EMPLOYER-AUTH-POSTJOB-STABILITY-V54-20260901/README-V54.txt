DEV GLOBAL JOBS V54 - EMPLOYER AUTH + POST JOB STABILITY

Purpose
Fix the second post-login Employer Post a Job blocker exposed after V53 removed the legacy dark V49 loader.

Root cause addressed
1. The global #dgj-splash white branded splash can cover /post-job?employer=1 during the employer auth return.
2. The legacy dgj-auth-route-bridge still watches /post-job and can re-navigate the route when /api/seekers/me is not ready/appropriate for the Employer Workspace transition.
3. Re-navigation restarts the global splash and can look like an endless Dev Global Jobs loading screen.

V54 behavior
- Employer Post a Job gets an early document class before body/splash creation.
- Both #dgj-splash and #dgj49-route-transition are hidden/removed for /post-job?employer=1.
- The generic seeker auth route bridge explicitly ignores the Employer Post a Job route.
- Employer authentication remains owned by the existing V46 Employer Workspace /api/v46/employer/me flow.
- V52 profile singleton and V53 dark-loader fixes are preserved.
- No backend, database, pricing, payments, CV storage, retention, Google Jobs, sitemap or service worker changes.
- No PM2 reload.
