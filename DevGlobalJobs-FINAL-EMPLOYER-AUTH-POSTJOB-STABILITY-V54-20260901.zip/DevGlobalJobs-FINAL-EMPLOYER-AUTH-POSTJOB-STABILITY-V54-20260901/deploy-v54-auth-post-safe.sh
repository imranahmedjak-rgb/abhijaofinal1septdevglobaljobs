#!/usr/bin/env bash
set -Eeuo pipefail
APP="/var/www/devglobaljobs"; DIST="$APP/dist"; PUBLIC="$DIST/public"; BASE="$(cd "$(dirname "$0")" && pwd)"; PAYLOAD="$BASE/payload"
sha(){ sha256sum "$1"|awk '{print $1}'; }
fail(){ echo; echo "SAFE STOP: $*"; exit 1; }
MUTATED=0; BACKUP=""
rollback(){
  if [ "$MUTATED" = 1 ] && [ -n "$BACKUP" ] && [ -d "$BACKUP" ]; then
    echo 'ROLLBACK: restoring exact pre-V54 frontend files...'
    cp -a "$BACKUP/dgj-v49-premium.js" "$PUBLIC/assets/dgj-v49-premium.js"
    cp -a "$BACKUP/dgj-v51-recruitment.js" "$PUBLIC/assets/dgj-v51-recruitment.js"
    cp -a "$BACKUP/dgj-v51-recruitment.css" "$PUBLIC/assets/dgj-v51-recruitment.css"
    cp -a "$BACKUP/index.html" "$PUBLIC/index.html"
    echo 'ROLLBACK COMPLETE.'
  fi
}
trap 'rc=$?; if [ $rc -ne 0 ]; then rollback; fi; exit $rc' EXIT
SERVER="754afef80c982fd75e6373d839893858a85f42909589da5ffd29d59c2fdbcd0c"
V45B="604bc9cdc6f60ec989bf9582558dbe5b470018e3e1ffb631a9866763d8859dfe"
V46B="bc5c4f4088cc434aabe5acfba0c9b521228330775799c55c2e941a95f05b205e"
V51B="904fa113528a1cde41dcaade4bbca5dc40083390f1e800bc490279f211e6235e"
EMP="dba27db99edc578ffeea08efb29edfea8af3b194edf6a4d130d150f0aa971ef6"
V49OLD="d7a9fff8892ac44e9f38a72fab121550d03ea3d9fc3557c29db251c1fdd3492f"
V49V53="11703b58327734c71c860f221fb72eaa331222bf4ec9d633875f5f2fc3ca1d86"
V51JS="f59c3d0b8096dcf2ec6921e395151e7f16ff8c1e6fe8c4dae15b22d6fa98b766"; V51CSS="7392d2c6f73cc67d3d9c2cb8a93b5a5c0a4f923438bd56bd0967855d4bc3b0f0"; V51IDX="335ed46c93b624e0ad2558de7683e91e64f564259838685147ef9f3f65b233b7"
V52JS="77531cfb660d72a3153e94738368929665d2920c506f4ad1129959df94c631bc"; V52CSS="830bdb46197607c1f433446be33267499726792dfd308baae90ea7a1a7493d60"; V52IDX="c22148523ad9d9b901eba0a2a539106332ef82a83b0e2de046f6fc72668fcdb9"
V53JS="453fa1d395c18e2ce45999aef26aefbeacb76228fcbd451cd5ba90d62f75e908"; V53CSS="24a942468e638f0d1a70ee2585aaffa73e68b4ed44fe4c9793047d46f9711b9f"; V53IDX="21c796511fe16ac11ab0afa59d3997c2d250f4bba3483a196cb06d0cc5ffc6c9"
NEWV49="11703b58327734c71c860f221fb72eaa331222bf4ec9d633875f5f2fc3ca1d86"
NEWJS="b57bc6b109750780caae871fa6f0ecb70f5d3cd399a539ec054678dbfca840b8"
NEWCSS="7aeef254a9f3e09719ed8d73484de5033a897b963facf5ba32acedfb23e14314"
NEWIDX="4eafdd57fe447d8016da28e81ca0d291f715c4d15c41ae410e0fffb64c8c5b27"

echo '============================================================'
echo 'DEV GLOBAL JOBS V54 - EMPLOYER AUTH + POST JOB STABILITY'
echo '============================================================'
echo '1/8 EXACT BASELINE + HEALTH'
[ "$(sha "$DIST/index.cjs")" = "$SERVER" ] || fail 'main runtime differs'
[ "$(sha "$DIST/dgj-v45-commercial.cjs")" = "$V45B" ] || fail 'V45 backend differs'
[ "$(sha "$DIST/dgj-v46-employer.cjs")" = "$V46B" ] || fail 'V46 backend differs'
[ "$(sha "$DIST/dgj-v51-recruitment.cjs")" = "$V51B" ] || fail 'V51 backend differs'
[ "$(sha "$PUBLIC/assets/dgj-v51-employer.js")" = "$EMP" ] || fail 'Employer JS differs'
V49="$(sha "$PUBLIC/assets/dgj-v49-premium.js")"; J="$(sha "$PUBLIC/assets/dgj-v51-recruitment.js")"; C="$(sha "$PUBLIC/assets/dgj-v51-recruitment.css")"; I="$(sha "$PUBLIC/index.html")"
if [ "$V49" = "$V49V53" ] && [ "$J" = "$V53JS" ] && [ "$C" = "$V53CSS" ] && [ "$I" = "$V53IDX" ]; then BASELINE=V53
elif [ "$V49" = "$V49OLD" ] && [ "$J" = "$V52JS" ] && [ "$C" = "$V52CSS" ] && [ "$I" = "$V52IDX" ]; then BASELINE=V52
elif [ "$V49" = "$V49OLD" ] && [ "$J" = "$V51JS" ] && [ "$C" = "$V51CSS" ] && [ "$I" = "$V51IDX" ]; then BASELINE=V51
else fail 'frontend is not an exact recognized V51/V52/V53 baseline'; fi
curl -fsS --max-time 15 http://127.0.0.1:8080/api/v51/config >/dev/null || fail 'V51 API unhealthy'
echo "PASS: exact $BASELINE baseline healthy."

echo '2/8 PACKAGE PREFLIGHT'
"$BASE/preflight-v54.sh"
sha256sum -c "$BASE/PAYLOAD-SHA256SUMS.txt" >/dev/null
echo 'PASS: V54 package verified.'

echo '3/8 PRIVATE ROLLBACK BACKUP'
BACKUP="/var/backups/devglobaljobs-v54-$(date +%Y%m%d-%H%M%S)"; mkdir -p "$BACKUP"
cp -a "$PUBLIC/assets/dgj-v49-premium.js" "$BACKUP/"
cp -a "$PUBLIC/assets/dgj-v51-recruitment.js" "$BACKUP/"
cp -a "$PUBLIC/assets/dgj-v51-recruitment.css" "$BACKUP/"
cp -a "$PUBLIC/index.html" "$BACKUP/"
echo "Backup: $BACKUP"

echo '4/8 ATOMIC FRONTEND INSTALL'
MUTATED=1
install -m 0644 "$PAYLOAD/dist/public/assets/dgj-v49-premium.js" "$PUBLIC/assets/dgj-v49-premium.js.v54"; mv -f "$PUBLIC/assets/dgj-v49-premium.js.v54" "$PUBLIC/assets/dgj-v49-premium.js"
install -m 0644 "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.js" "$PUBLIC/assets/dgj-v51-recruitment.js.v54"; mv -f "$PUBLIC/assets/dgj-v51-recruitment.js.v54" "$PUBLIC/assets/dgj-v51-recruitment.js"
install -m 0644 "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.css" "$PUBLIC/assets/dgj-v51-recruitment.css.v54"; mv -f "$PUBLIC/assets/dgj-v51-recruitment.css.v54" "$PUBLIC/assets/dgj-v51-recruitment.css"
install -m 0644 "$PAYLOAD/dist/public/index.html" "$PUBLIC/index.html.v54"; mv -f "$PUBLIC/index.html.v54" "$PUBLIC/index.html"
[ "$(sha "$PUBLIC/assets/dgj-v49-premium.js")" = "$NEWV49" ] || fail 'V49 hash mismatch after install'
[ "$(sha "$PUBLIC/assets/dgj-v51-recruitment.js")" = "$NEWJS" ] || fail 'recruitment JS hash mismatch after install'
[ "$(sha "$PUBLIC/assets/dgj-v51-recruitment.css")" = "$NEWCSS" ] || fail 'recruitment CSS hash mismatch after install'
[ "$(sha "$PUBLIC/index.html")" = "$NEWIDX" ] || fail 'index hash mismatch after install'
echo 'PASS: V54 frontend files installed.'

echo '5/8 ORIGIN ASSET + ROUTE-GUARD CONTRACT'
TMP="$(mktemp -d)"
curl -fsS --max-time 20 http://127.0.0.1:8080/ -o "$TMP/home" || fail 'origin home failed'
grep -Fq '/assets/dgj-v49-premium.js?v=54.0.0' "$TMP/home" || fail 'V54 V49 ref missing'
grep -Fq '/assets/dgj-v51-recruitment.js?v=54.0.0' "$TMP/home" || fail 'V54 recruitment JS ref missing'
grep -Fq '/assets/dgj-v51-recruitment.css?v=54.0.0' "$TMP/home" || fail 'V54 CSS ref missing'
grep -Fq 'dgj-v54-post-route-guard' "$TMP/home" || fail 'V54 early guard missing'
grep -Fq "new URLSearchParams(q).get('employer')==='1') return;" "$TMP/home" || fail 'V54 auth bridge bypass missing'
curl -fsS --max-time 20 'http://127.0.0.1:8080/assets/dgj-v51-recruitment.js?v=54.0.0' -o "$TMP/recruitment" || fail 'V54 JS origin failed'
[ "$(sha "$TMP/recruitment")" = "$NEWJS" ] || fail 'origin recruitment JS bytes mismatch'
rm -rf "$TMP"
echo 'PASS: V54 origin contract verified.'

echo '6/8 PROTECTED BACKEND + PRIVATE CV API'
[ "$(sha "$DIST/index.cjs")" = "$SERVER" ] || fail 'main runtime changed'
[ "$(sha "$DIST/dgj-v45-commercial.cjs")" = "$V45B" ] || fail 'V45 backend changed'
[ "$(sha "$DIST/dgj-v46-employer.cjs")" = "$V46B" ] || fail 'V46 backend changed'
[ "$(sha "$DIST/dgj-v51-recruitment.cjs")" = "$V51B" ] || fail 'V51 backend changed'
curl -fsS --max-time 15 http://127.0.0.1:8080/api/v51/config >/dev/null || fail 'V51 API failed'
echo 'PASS: backend remains unchanged and healthy.'

echo '7/8 NO RELOAD / NO DATABASE MUTATION'
echo 'PASS: frontend-only V54 does not reload PM2 and does not run database migration.'

echo '8/8 FINAL'
MUTATED=0; trap - EXIT
echo '============================================================'
echo 'SUCCESS: V54 EMPLOYER AUTH + POST JOB STABILITY IS LIVE'
echo '============================================================'
echo '✓ Global white Dev Global Jobs splash is disabled on authenticated Employer Post a Job'
echo '✓ Legacy auth-route bridge no longer reloads /post-job?employer=1'
echo '✓ Legacy V49 dark Post a Job mask remains disabled'
echo '✓ V52 single Application Tracker fix retained'
echo '✓ V51 ATS/backend/private CV/180-day retention unchanged'
echo "Rollback backup: $BACKUP"
