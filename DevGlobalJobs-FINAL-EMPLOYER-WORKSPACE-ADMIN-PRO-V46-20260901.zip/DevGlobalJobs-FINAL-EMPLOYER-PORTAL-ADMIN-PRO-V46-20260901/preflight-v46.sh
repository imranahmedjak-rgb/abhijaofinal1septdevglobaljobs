#!/usr/bin/env bash
set -Eeuo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
P="$HERE/payload"
fail(){ echo "SAFE STOP: $*" >&2; exit 1; }
for c in sha256sum node grep; do command -v "$c" >/dev/null 2>&1 || fail "Required command missing: $c"; done
[ -f "$P/dist/index.cjs" ] || fail "index.cjs missing"
[ -f "$P/dist/dgj-v46-employer.cjs" ] || fail "V46 employer module missing"
[ -f "$P/dist/public/index.html" ] || fail "public index missing"
[ -f "$P/dist/public/assets/dgj-v46-employer.js" ] || fail "V46 employer UI missing"
[ -f "$P/dist/public/assets/dgj-v46-employer.css" ] || fail "V46 employer CSS missing"
node --check "$P/dist/index.cjs" >/dev/null
node --check "$P/dist/dgj-v46-employer.cjs" >/dev/null
node --check "$P/dist/public/assets/dgj-v46-employer.js" >/dev/null

grep -Fq '/employer/sign-in' "$P/dist/index.cjs" || fail "Employer sign-in route missing"
grep -Fq 'Dev Global Jobs for Employers' "$P/dist/index.cjs" || fail "Employer sign-in branding missing"
grep -Fq 'dgj_v46_employer_profiles' "$P/dist/dgj-v46-employer.cjs" || fail "Employer profile table missing"
grep -Fq '/api/v46/employer/overview' "$P/dist/dgj-v46-employer.cjs" || fail "Employer overview API missing"
grep -Fq '/api/v46/admin/employers' "$P/dist/dgj-v46-employer.cjs" || fail "Admin employer registry API missing"
grep -Fq 'company_website' "$P/dist/dgj-v46-employer.cjs" || fail "Company website field missing"
grep -Fq 'address_line1' "$P/dist/dgj-v46-employer.cjs" || fail "Business address fields missing"
grep -Fq 'function perf(' "$P/dist/public/assets/dgj-v46-employer.js" || fail "Public-performance parity algorithm missing"
grep -Fq 'Same counters shown on public job pages' "$P/dist/public/assets/dgj-v46-employer.js" || fail "Analytics parity UI missing"
grep -Fq "location.replace('/employer/post-job')" "$P/dist/public/assets/dgj-v46-employer.js" || fail "Post a Job employer routing missing"
grep -Fq 'Continue with Google or your verified email account' "$P/dist/index.cjs" || fail "Google/email employer auth copy missing"
grep -Fq 'Billing & Payments' "$P/dist/public/assets/dgj-v46-employer.js" || fail "Employer billing missing"
grep -Fq 'Plans & Credits' "$P/dist/public/assets/dgj-v46-employer.js" || fail "Employer plans missing"
grep -Fq 'Premium Boosts' "$P/dist/public/assets/dgj-v46-employer.js" || fail "Employer Boost management missing"
grep -Fq 'dgj46-admin-login-only' "$P/dist/public/assets/dgj-v46-employer.js" || fail "Admin login isolation logic missing"
grep -Fq '#dgj46-admin-login-screen' "$P/dist/public/assets/dgj-v46-employer.css" || fail "Admin login full-screen lock CSS missing"
grep -Fq 'Employer Accounts' "$P/dist/public/assets/dgj-v46-employer.js" || fail "Admin employer accounts UI missing"
grep -Fq "['/terms','/privacy','/pricing']" "$P/dist/public/assets/dgj-v46-employer.js" || fail "Existing legal/pricing supplements missing"
grep -Fq 'dgj-v45-commercial.js?v=45.1.0' "$P/dist/public/index.html" || fail "V45 commercial UI reference not preserved"
grep -Fq 'dgj-v46-employer.js?v=46.0.0' "$P/dist/public/index.html" || fail "V46 UI not linked"
grep -Fq 'index-DGJ45auth-v43-youth.js' "$P/dist/public/index.html" || fail "V44 Youth SPA reference not preserved"
for marker in 'DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27' 'devglobaljobs-social-share.png' 'const indexableJobs = latestJobs;' 'const indexableJobs = jobIds;' 'const indexableJobs = allJobIds;'; do grep -Fq "$marker" "$P/dist/index.cjs" || fail "Protected runtime marker missing: $marker"; done

echo "PASS: V46 Employer Workspace, public analytics parity, employer-only Post a Job routing, admin login isolation and protected V45/V44 architecture verified."
