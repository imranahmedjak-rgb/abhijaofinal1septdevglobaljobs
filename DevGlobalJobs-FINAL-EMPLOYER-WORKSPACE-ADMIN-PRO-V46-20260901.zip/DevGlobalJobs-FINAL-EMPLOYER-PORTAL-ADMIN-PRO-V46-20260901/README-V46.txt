DEV GLOBAL JOBS V46
FINAL EMPLOYER WORKSPACE + ADMIN PROFESSIONALISATION

Purpose
-------
Add a dedicated international-standard Employer Workspace above the already-live V45 commercial engine, without redesigning or replacing unrelated website systems.

Employer flow
-------------
Post a Job (header/footer) -> Employer Sign In -> Employer onboarding -> Employer Dashboard -> existing Post a Job form.

Employer authentication reuses the existing secure Google + verified-email identity system, while employer company/profile data is stored separately. Job-seeker sign-in/profile behavior is not replaced.

Employer Workspace includes:
- Overview
- My Jobs
- Post a Job
- Analytics
- Premium Boosts
- Billing & Payments
- Plans & Credits
- Company Profile
- Company website + full business address fields
- Current free monthly allowance
- V45 paid posting/payment request history
- V45 employer plan visibility
- V45 Premium Boost requests

Analytics parity
----------------
Employer Job Performance deliberately uses the same existing Views / Clicks / Shares calculation used by public Dev Global Jobs job cards/detail pages, using the same job ID, Featured status and posted date. It does not create a competing analytics counter.

Admin improvements
------------------
- Secure Sign In is forced into an isolated full-viewport admin state.
- Growth/admin dashboard content cannot render visibly below the login screen.
- If the existing admin session is already authenticated, /admin routes to /admin/dashboard.
- Employer Accounts admin registry shows employer profile, company site/address, posting activity, pending payments, active Boosts and plans.
- Existing V45 Promotion Centre remains unchanged.

Legal/payment integration
-------------------------
The existing Pricing, Terms and Privacy pages are not replaced. V46 adds employer/paid-placement/Boost/payment/privacy supplements to those existing pages.

Database
--------
V46 creates only one additive table: dgj_v46_employer_profiles.
Existing jobs, users, applications and V45 commercial data are not migrated or rewritten by the V46 installer.

Protected
---------
V45 commercial module/UI/CSS/logo remain byte-for-byte unchanged.
V44 Youth bundle, Google JobPosting, sitemap architecture, V42 social preview, service worker and brand contract remain protected.
