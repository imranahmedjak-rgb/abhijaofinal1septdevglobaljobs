#!/usr/bin/env bash
set -Eeuo pipefail
APP="/var/www/devglobaljobs"
DIST="$APP/dist"
PUBLIC="$DIST/public"
ASSETS="$PUBLIC/assets"
PM2_APP="devglobaljobs"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/var/backups/devglobaljobs-employer-v46-${STAMP}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$HERE/payload"

# Exact successful V45 production baseline.
BASE_SERVER_SHA="14013f06f03996b0818714f4572f12409d3c345445a0579c82ade920b56df0ef"
BASE_V45_MODULE_SHA="d8ba3950fc169dfaa94fa061b466dd3152bc969a375b6e31ed87f7155af09b0f"
BASE_INDEX_SHA="cdf2cea722c780d11d9a99234da97079409a8e9fe4843ad04f2fb716ba8c160f"
BASE_V45_UI_SHA="a52126b670737e30dd6f929fb6f901d2e66bf99f899d65a22199ce3e0952a801"
BASE_V45_CSS_SHA="cd3038190e9fc212058fd53bdf506b6bd28661764fdb083605e589d54819dfe7"
BASE_V45_LOGO_SHA="66d36152a4de7a1f2d7270a3901ebc204cc4592ca66f93a2370a6110d4eb05ea"
BASE_MAIN_SHA="ff420f2b6b88f06f5a9f6c9e3bc2ae88b456bbca5bb6a76b3047992874a909df"
BASE_GOOGLE_JOBS_SHA="efd02864b5ea0703465ab7d62a6b8dc43d7a48e0ea074082a45f6a7adc23ddf6"
BASE_SOCIAL_SHA="528878c345ddf89bde59041513d2b406fb1c8bcb786ee9874413247a6a6cbd92"
BASE_CONTRACT_SHA="00e06a8e7592a5aff18fcfa21492b43a2ad513c46a473d45f45367c7765295b4"
BASE_SW_SHA="7f6986e064891c43437df7f35fd4c2a7050d1ce82bd0120b12afb7e9fa1733f3"
BASE_BRAND_JS_SHA="c65297262b99483d6fa87e4a2e469417e98592162329d1f1646dfab91e02fdd4"

NEW_SERVER_SHA="62553713761f298ec7dd50a50f32b920494f9624a6f9f0648378239fd408bb94"
NEW_V46_MODULE_SHA="f66fe32c6c7800ccfa4d7963edd2d5025f323938bdb190fdb4b3a6e8a039b1ca"
NEW_INDEX_SHA="0fa228659d896bb2fa081462c64a78cd6cd60632ca1a92d053f12553bf8b9dbd"
NEW_V46_UI_SHA="870938e63e0e1807f22a6fa14ffef636ddb4b37717d7281c28318f74b1057bbb"
NEW_V46_CSS_SHA="d541842ee81e1b7e9256a32bff9654709d1ff6c78edae7fb2c91a9762a195b9c"

MUTATED=0
sha(){ sha256sum "$1" | awk '{print $1}'; }
fail(){ echo; echo "============================================================"; echo "SAFE STOP: $*"; echo "============================================================"; exit 1; }
rollback(){
  local rc=$?
  if [ "$MUTATED" = "1" ]; then
    echo; echo "ROLLBACK: restoring exact pre-V46 production files..."; set +e
    [ -f "$BACKUP/index.cjs" ] && cp -af "$BACKUP/index.cjs" "$DIST/index.cjs"
    [ -f "$BACKUP/index.html" ] && cp -af "$BACKUP/index.html" "$PUBLIC/index.html"
    if [ -f "$BACKUP/dgj-v46-employer.cjs" ]; then cp -af "$BACKUP/dgj-v46-employer.cjs" "$DIST/dgj-v46-employer.cjs"; else rm -f "$DIST/dgj-v46-employer.cjs"; fi
    if [ -f "$BACKUP/dgj-v46-employer.js" ]; then cp -af "$BACKUP/dgj-v46-employer.js" "$ASSETS/dgj-v46-employer.js"; else rm -f "$ASSETS/dgj-v46-employer.js"; fi
    if [ -f "$BACKUP/dgj-v46-employer.css" ]; then cp -af "$BACKUP/dgj-v46-employer.css" "$ASSETS/dgj-v46-employer.css"; else rm -f "$ASSETS/dgj-v46-employer.css"; fi
    pm2 reload "$PM2_APP" --update-env >/dev/null 2>&1 || true
    echo "ROLLBACK COMPLETE. Pre-V46 website files restored."
    echo "Note: additive dgj_v46_employer_profiles table may remain; V46 never deletes existing jobs/users/applications."
    set -e
  fi
  exit "$rc"
}
trap rollback ERR INT TERM

echo "============================================================"
echo "DEV GLOBAL JOBS V46"
echo "EMPLOYER WORKSPACE + ADMIN PROFESSIONALISATION"
echo "============================================================"
[ "$(id -u)" = "0" ] || fail "Run as root."
for c in sha256sum node curl pm2 install grep mkdir cp mv chmod find stat; do command -v "$c" >/dev/null 2>&1 || fail "Required command missing: $c"; done
[ -d "$ASSETS" ] || fail "Public assets directory missing."

echo; echo "1/8 EXACT SUCCESSFUL V45 BASELINE + HEALTH"
[ "$(sha "$DIST/index.cjs")" = "$BASE_SERVER_SHA" ] || fail "Live server is not exact successful V45 baseline."
[ "$(sha "$DIST/dgj-v45-commercial.cjs")" = "$BASE_V45_MODULE_SHA" ] || fail "V45 commercial module changed."
[ "$(sha "$PUBLIC/index.html")" = "$BASE_INDEX_SHA" ] || fail "Live public index is not exact successful V45 baseline."
[ "$(sha "$ASSETS/dgj-v45-commercial.js")" = "$BASE_V45_UI_SHA" ] || fail "V45 UI changed."
[ "$(sha "$ASSETS/dgj-v45-commercial.css")" = "$BASE_V45_CSS_SHA" ] || fail "V45 CSS changed."
[ "$(sha "$ASSETS/dgj-admin-logo-v45.png")" = "$BASE_V45_LOGO_SHA" ] || fail "Admin logo changed."
[ "$(sha "$ASSETS/index-DGJ45auth-v43-youth.js")" = "$BASE_MAIN_SHA" ] || fail "V44 Youth SPA changed."
[ "$(sha "$PUBLIC/dgj-google-jobs-v27.js")" = "$BASE_GOOGLE_JOBS_SHA" ] || fail "Google Jobs companion changed."
[ "$(sha "$PUBLIC/devglobaljobs-social-share.png")" = "$BASE_SOCIAL_SHA" ] || fail "Social preview changed."
[ "$(sha "$PUBLIC/brand-contract.json")" = "$BASE_CONTRACT_SHA" ] || fail "Brand contract changed."
[ "$(sha "$PUBLIC/sw.js")" = "$BASE_SW_SHA" ] || fail "Service worker changed."
[ "$(sha "$PUBLIC/dgj-brand-contract-v27.js")" = "$BASE_BRAND_JS_SHA" ] || fail "Brand JS changed."
curl -fsS --max-time 20 http://127.0.0.1:8080/api/jobs/stats >/dev/null || fail "Local API unhealthy."
pm2 describe "$PM2_APP" | grep -q 'online' || fail "PM2 app not online."
echo "PASS: exact V45 baseline and protected V44 files verified."

echo; echo "2/8 PACKAGE + FEATURE VALIDATION"
[ "$(sha "$PAYLOAD/dist/index.cjs")" = "$NEW_SERVER_SHA" ] || fail "V46 server payload checksum mismatch."
[ "$(sha "$PAYLOAD/dist/dgj-v46-employer.cjs")" = "$NEW_V46_MODULE_SHA" ] || fail "V46 module checksum mismatch."
[ "$(sha "$PAYLOAD/dist/public/index.html")" = "$NEW_INDEX_SHA" ] || fail "V46 index checksum mismatch."
[ "$(sha "$PAYLOAD/dist/public/assets/dgj-v46-employer.js")" = "$NEW_V46_UI_SHA" ] || fail "V46 UI checksum mismatch."
[ "$(sha "$PAYLOAD/dist/public/assets/dgj-v46-employer.css")" = "$NEW_V46_CSS_SHA" ] || fail "V46 CSS checksum mismatch."
node --check "$PAYLOAD/dist/index.cjs" >/dev/null
node --check "$PAYLOAD/dist/dgj-v46-employer.cjs" >/dev/null
node --check "$PAYLOAD/dist/public/assets/dgj-v46-employer.js" >/dev/null
grep -Fq 'Dev Global Jobs for Employers' "$PAYLOAD/dist/index.cjs" || fail "Employer sign-in missing."
grep -Fq '/api/v46/employer/overview' "$PAYLOAD/dist/dgj-v46-employer.cjs" || fail "Employer dashboard API missing."
grep -Fq 'Same counters shown on public job pages' "$PAYLOAD/dist/public/assets/dgj-v46-employer.js" || fail "Public analytics parity missing."
grep -Fq 'dgj46-admin-login-only' "$PAYLOAD/dist/public/assets/dgj-v46-employer.css" || fail "Admin login isolation missing."
grep -Fq 'Employer Accounts' "$PAYLOAD/dist/public/assets/dgj-v46-employer.js" || fail "Admin Employer Accounts missing."
echo "PASS: reviewed V46 Employer Workspace payload verified."

echo; echo "3/8 PROTECTED COMMERCIAL / SEO / BRAND CHECK"
# Existing V45 commercial engine files are intentionally not replaced by V46.
[ "$(sha "$PAYLOAD/dist/dgj-v45-commercial.cjs")" = "$BASE_V45_MODULE_SHA" ] || fail "Packaged V45 reference module changed."
[ "$(sha "$PAYLOAD/dist/public/assets/dgj-v45-commercial.js")" = "$BASE_V45_UI_SHA" ] || fail "Packaged V45 reference UI changed."
[ "$(sha "$PAYLOAD/dist/public/assets/dgj-v45-commercial.css")" = "$BASE_V45_CSS_SHA" ] || fail "Packaged V45 reference CSS changed."
[ "$(sha "$PAYLOAD/dist/public/assets/dgj-admin-logo-v45.png")" = "$BASE_V45_LOGO_SHA" ] || fail "Packaged admin logo changed."
for marker in 'DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27' 'devglobaljobs-social-share.png' 'const indexableJobs = latestJobs;' 'const indexableJobs = jobIds;' 'const indexableJobs = allJobIds;'; do grep -Fq "$marker" "$PAYLOAD/dist/index.cjs" || fail "Protected runtime marker missing: $marker"; done
echo "PASS: V45 monetisation, V44 Youth, Google Jobs, sitemap, social and brand architecture retained."

echo; echo "4/8 PRIVATE ROLLBACK BACKUP"
mkdir -p "$BACKUP"; chmod 700 "$BACKUP"
cp -af "$DIST/index.cjs" "$BACKUP/index.cjs"
cp -af "$PUBLIC/index.html" "$BACKUP/index.html"
[ -f "$DIST/dgj-v46-employer.cjs" ] && cp -af "$DIST/dgj-v46-employer.cjs" "$BACKUP/dgj-v46-employer.cjs" || true
[ -f "$ASSETS/dgj-v46-employer.js" ] && cp -af "$ASSETS/dgj-v46-employer.js" "$BACKUP/dgj-v46-employer.js" || true
[ -f "$ASSETS/dgj-v46-employer.css" ] && cp -af "$ASSETS/dgj-v46-employer.css" "$BACKUP/dgj-v46-employer.css" || true
chmod -R go-rwx "$BACKUP"
echo "Backup: $BACKUP"
echo "PASS: backup is private under /var/backups only."

echo; echo "5/8 ATOMIC V46 INSTALL"
tmp_server="$DIST/.index.cjs.v46.$$"; tmp_module="$DIST/.dgj-v46-employer.cjs.$$"; tmp_index="$PUBLIC/.index.html.v46.$$"; tmp_ui="$ASSETS/.dgj-v46-employer.js.$$"; tmp_css="$ASSETS/.dgj-v46-employer.css.$$"
install -m 0644 "$PAYLOAD/dist/index.cjs" "$tmp_server"
install -m 0644 "$PAYLOAD/dist/dgj-v46-employer.cjs" "$tmp_module"
install -m 0644 "$PAYLOAD/dist/public/index.html" "$tmp_index"
install -m 0644 "$PAYLOAD/dist/public/assets/dgj-v46-employer.js" "$tmp_ui"
install -m 0644 "$PAYLOAD/dist/public/assets/dgj-v46-employer.css" "$tmp_css"
mv -f "$tmp_module" "$DIST/dgj-v46-employer.cjs"; mv -f "$tmp_ui" "$ASSETS/dgj-v46-employer.js"; mv -f "$tmp_css" "$ASSETS/dgj-v46-employer.css"; mv -f "$tmp_index" "$PUBLIC/index.html"; mv -f "$tmp_server" "$DIST/index.cjs"
MUTATED=1
[ "$(sha "$DIST/index.cjs")" = "$NEW_SERVER_SHA" ]; [ "$(sha "$DIST/dgj-v46-employer.cjs")" = "$NEW_V46_MODULE_SHA" ]; [ "$(sha "$PUBLIC/index.html")" = "$NEW_INDEX_SHA" ]; [ "$(sha "$ASSETS/dgj-v46-employer.js")" = "$NEW_V46_UI_SHA" ]; [ "$(sha "$ASSETS/dgj-v46-employer.css")" = "$NEW_V46_CSS_SHA" ]
echo "PASS: only V46 runtime/index + new Employer Workspace assets installed."

echo; echo "6/8 PM2 RELOAD + ADDITIVE V46 INITIALISATION"
pm2 reload "$PM2_APP" --update-env
sleep 4
curl -fsS --max-time 20 http://127.0.0.1:8080/api/jobs/stats >/dev/null || false
V45="$(curl -fsS --max-time 20 http://127.0.0.1:8080/api/v45/commerce/config)"; printf '%s' "$V45" | grep -Fq '"version":"45.1.0"' || false
EMP_CODE="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 20 http://127.0.0.1:8080/api/v46/employer/me || true)"; [ "$EMP_CODE" = "401" ] || { echo "Unexpected unauthenticated employer status: $EMP_CODE"; false; }
ADMIN_CODE="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 20 http://127.0.0.1:8080/api/v46/admin/employers || true)"; case "$ADMIN_CODE" in 401|403) :;; *) echo "Unexpected unauthenticated admin status: $ADMIN_CODE"; false;; esac
SIGNIN="$(curl -fsS --max-time 20 http://127.0.0.1:8080/employer/sign-in)"; printf '%s' "$SIGNIN" | grep -Fq 'Dev Global Jobs for Employers' || false; printf '%s' "$SIGNIN" | grep -Fq 'Google' || false
echo "PASS: V46 employer table initialised; employer/admin APIs protected; Employer Sign In live."

echo; echo "7/8 BYTE-FOR-BYTE PROTECTED FILE CHECK"
[ "$(sha "$DIST/dgj-v45-commercial.cjs")" = "$BASE_V45_MODULE_SHA" ] || false
[ "$(sha "$ASSETS/dgj-v45-commercial.js")" = "$BASE_V45_UI_SHA" ] || false
[ "$(sha "$ASSETS/dgj-v45-commercial.css")" = "$BASE_V45_CSS_SHA" ] || false
[ "$(sha "$ASSETS/dgj-admin-logo-v45.png")" = "$BASE_V45_LOGO_SHA" ] || false
[ "$(sha "$ASSETS/index-DGJ45auth-v43-youth.js")" = "$BASE_MAIN_SHA" ] || false
[ "$(sha "$PUBLIC/dgj-google-jobs-v27.js")" = "$BASE_GOOGLE_JOBS_SHA" ] || false
[ "$(sha "$PUBLIC/devglobaljobs-social-share.png")" = "$BASE_SOCIAL_SHA" ] || false
[ "$(sha "$PUBLIC/brand-contract.json")" = "$BASE_CONTRACT_SHA" ] || false
[ "$(sha "$PUBLIC/sw.js")" = "$BASE_SW_SHA" ] || false
[ "$(sha "$PUBLIC/dgj-brand-contract-v27.js")" = "$BASE_BRAND_JS_SHA" ] || false
if find "$PUBLIC" -type f \( -iname '*payment-receipt*' -o -iname '*receipt*.pdf' -o -iname '*receipt*.jpg' -o -iname '*.sql' -o -iname '*.dump' -o -iname '.env*' \) -print -quit | grep -q .; then echo "Sensitive receipt/database/env-like file detected under public web root."; false; fi
echo "PASS: V45 commercial assets and protected V44/SEO/security files unchanged."

echo; echo "8/8 FINAL ORIGIN + PUBLIC HEALTH"
curl -fsS --max-time 20 http://127.0.0.1:8080/assets/dgj-v46-employer.js?v=46.0.0 >/dev/null || false
curl -fsS --max-time 20 http://127.0.0.1:8080/assets/dgj-v46-employer.css?v=46.0.0 >/dev/null || false
curl -fsS --max-time 20 http://127.0.0.1:8080/sitemap-index.xml | grep -q '<sitemapindex' || false
curl -fsS --max-time 20 https://devglobaljobs.com/ >/dev/null || false

echo; echo "============================================================"
echo "SUCCESS: V46 EMPLOYER WORKSPACE + ADMIN PROFESSIONALISATION IS LIVE"
echo "============================================================"
echo "✓ Every public Post a Job entry routes to dedicated Employer access"
echo "✓ Job Seeker sign-in/profile remains unchanged"
echo "✓ Employer Sign In supports existing secure Google + verified email authentication"
echo "✓ Employer onboarding adds company, website, address, country, industry, size and contact details"
echo "✓ Employer record synchronises into existing employer CRM/subscription data"
echo "✓ Employer Dashboard: Overview / My Jobs / Post a Job / Analytics / Boosts / Billing / Plans / Company Profile"
echo "✓ Existing Post a Job form opens inside secure Employer Workspace"
echo "✓ Employer Job Performance uses the exact same Views / Clicks / Shares calculation as public jobs"
echo "✓ Premium Boost uses the existing V45 payment/receipt/admin-verification engine"
echo "✓ Billing shows Wise / PayPal / existing bank-transfer flow and request history"
echo "✓ Existing pricing / terms / privacy pages receive employer commercial supplements"
echo "✓ Admin login is visually isolated; Growth/dashboard content cannot appear below Secure Sign In"
echo "✓ Already-authenticated admin visiting /admin is redirected to /admin/dashboard"
echo "✓ Admin Employer Accounts registry adds company/location/job/payment/Boost/plan visibility"
echo "✓ V45 commercial engine remains byte-for-byte unchanged"
echo "✓ V44 Youth / Google JobPosting / sitemap / V42 social / service worker / brand lock preserved"
echo "✓ V46 DB change is additive: dgj_v46_employer_profiles only"
echo "Rollback backup: $BACKUP"
echo "============================================================"
trap - ERR INT TERM
