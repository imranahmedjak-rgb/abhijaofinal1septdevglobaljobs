Dev Global Jobs V49
International Employer & Administration Premium Experience

Deploy only on the exact successful V48-FIXED production baseline.
Run preflight-v49.sh before deployment, then deploy-v49-premium-safe.sh.

Key workflow:
- Signed-out Post a Job -> professional Employer Sign In.
- Signed-in Post a Job -> Employer Workspace publishing shell, with no unsafe insertBefore race.
- Free quota and V45 paid review remain unchanged.
- Plans & Credits displays Regular ($29/30d), Featured ($79/45d), Premium Boost ($49/15d) plus active credits.
- Boost uses the existing V45 payment/receipt/admin verification engine.
- Billing payment history is structured and responsive.
- Company Profile can securely upload PNG/JPG/WebP logo up to 2 MB.
- Admin login/dashboard receives presentation and readability improvements without replacing admin business APIs.

Rollback:
The deployment script restores modified files on failure. The additive nullable company_logo_url database column may remain after a file rollback; it is backward compatible and does not rewrite existing records.
