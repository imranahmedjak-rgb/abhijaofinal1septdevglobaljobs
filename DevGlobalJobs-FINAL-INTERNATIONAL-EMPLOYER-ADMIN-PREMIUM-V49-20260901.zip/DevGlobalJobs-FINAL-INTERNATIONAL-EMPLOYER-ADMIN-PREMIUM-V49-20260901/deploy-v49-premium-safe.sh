#!/usr/bin/env bash
set -Eeuo pipefail
APP="/var/www/devglobaljobs"
DIST="$APP/dist"
PUBLIC="$DIST/public"
ASSETS="$PUBLIC/assets"
PM2_APP="devglobaljobs"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/var/backups/devglobaljobs-employer-admin-v49-${STAMP}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$HERE/payload"

# Exact successful V48-FIXED live baseline.
BASE_SERVER_SHA="754afef80c982fd75e6373d839893858a85f42909589da5ffd29d59c2fdbcd0c"
BASE_INDEX_SHA="1ea7a0b5e404e114315818205fa274548783af3f5894bb3d86c974094e7a15d6"
BASE_V48_JS_SHA="a1eb6a365c41648762f924e9051940930bbc273c5d93d61fb134f0c8cf3b580b"
BASE_V48_CSS_SHA="a17de7c0bbf56a6c572c308e3be60c2a8f95f3e3cdff294157f4b030acb06f2e"
BASE_V46_MODULE_SHA="f66fe32c6c7800ccfa4d7963edd2d5025f323938bdb190fdb4b3a6e8a039b1ca"
BASE_V46_UI_SHA="870938e63e0e1807f22a6fa14ffef636ddb4b37717d7281c28318f74b1057bbb"
BASE_V46_CSS_SHA="d541842ee81e1b7e9256a32bff9654709d1ff6c78edae7fb2c91a9762a195b9c"
BASE_V45_MODULE_SHA="d8ba3950fc169dfaa94fa061b466dd3152bc969a375b6e31ed87f7155af09b0f"
BASE_V45_UI_SHA="a52126b670737e30dd6f929fb6f901d2e66bf99f899d65a22199ce3e0952a801"
BASE_V45_CSS_SHA="cd3038190e9fc212058fd53bdf506b6bd28661764fdb083605e589d54819dfe7"
BASE_V45_LOGO_SHA="66d36152a4de7a1f2d7270a3901ebc204cc4592ca66f93a2370a6110d4eb05ea"
BASE_MAIN_SHA="ff420f2b6b88f06f5a9f6c9e3bc2ae88b456bbca5bb6a76b3047992874a909df"
BASE_GOOGLE_JOBS_SHA="efd02864b5ea0703465ab7d62a6b8dc43d7a48e0ea074082a45f6a7adc23ddf6"
BASE_SOCIAL_SHA="528878c345ddf89bde59041513d2b406fb1c8bcb786ee9874413247a6a6cbd92"
BASE_CONTRACT_SHA="00e06a8e7592a5aff18fcfa21492b43a2ad513c46a473d45f45367c7765295b4"
BASE_SW_SHA="7f6986e064891c43437df7f35fd4c2a7050d1ce82bd0120b12afb7e9fa1733f3"
BASE_BRAND_JS_SHA="c65297262b99483d6fa87e4a2e469417e98592162329d1f1646dfab91e02fdd4"

NEW_V46_MODULE_SHA="43830d9aa2887ba7d9e136a84b31dc3ca915d722124ff7c160dd29139ce0c75b"
NEW_V46_UI_SHA="e206733dee07e3ce73e5457e39d110a532520d56e38ebfd59dc879c7a514c715"
NEW_V49_JS_SHA="d7a9fff8892ac44e9f38a72fab121550d03ea3d9fc3557c29db251c1fdd3492f"
NEW_V49_CSS_SHA="5929d5a9edb36e5670dadf0511508e945751b510dbb20fead09116f5e1c41e2f"
NEW_INDEX_SHA="f7fcf7953928bbc1573c1ae471692898230b86b2ca07da72b89f3e9344ad5a5f"

MUTATED=0
sha(){ sha256sum "$1" | awk '{print $1}'; }
fail(){ echo; echo "============================================================"; echo "SAFE STOP: $*"; echo "NOTHING UNVERIFIED WILL BE KEPT."; echo "============================================================"; exit 1; }
rollback(){
  local rc=$?
  if [ "$MUTATED" = "1" ]; then
    echo; echo "ROLLBACK: restoring exact pre-V49 V48 production files..."; set +e
    [ -f "$BACKUP/dgj-v46-employer.cjs" ] && cp -af "$BACKUP/dgj-v46-employer.cjs" "$DIST/dgj-v46-employer.cjs"
    [ -f "$BACKUP/dgj-v46-employer.js" ] && cp -af "$BACKUP/dgj-v46-employer.js" "$ASSETS/dgj-v46-employer.js"
    [ -f "$BACKUP/index.html" ] && cp -af "$BACKUP/index.html" "$PUBLIC/index.html"
    if [ -f "$BACKUP/dgj-v49-premium.js" ]; then cp -af "$BACKUP/dgj-v49-premium.js" "$ASSETS/dgj-v49-premium.js"; else rm -f "$ASSETS/dgj-v49-premium.js"; fi
    if [ -f "$BACKUP/dgj-v49-premium.css" ]; then cp -af "$BACKUP/dgj-v49-premium.css" "$ASSETS/dgj-v49-premium.css"; else rm -f "$ASSETS/dgj-v49-premium.css"; fi
    pm2 reload "$PM2_APP" --update-env >/dev/null 2>&1 || true
    echo "ROLLBACK COMPLETE. Exact V48 files restored. The additive nullable company_logo_url DB column may remain and is backward compatible."
    set -e
  fi
  exit "$rc"
}
trap rollback ERR INT TERM

echo "============================================================"
echo "DEV GLOBAL JOBS V49"
echo "INTERNATIONAL EMPLOYER + ADMIN PREMIUM EXPERIENCE"
echo "POST A JOB DOM FIX · PRODUCTS · BOOST · PROFILE LOGO · PWA"
echo "============================================================"
[ "$(id -u)" = "0" ] || fail "Run as root."
for c in sha256sum node curl pm2 install grep mkdir cp mv chmod find stat; do command -v "$c" >/dev/null 2>&1 || fail "Required command missing: $c"; done
[ -d "$ASSETS" ] || fail "Public assets directory missing."

echo; echo "1/8 EXACT SUCCESSFUL V48-FIXED BASELINE + HEALTH"
[ "$(sha "$DIST/index.cjs")" = "$BASE_SERVER_SHA" ] || fail "Live server is not exact successful V48-FIXED baseline."
[ "$(sha "$PUBLIC/index.html")" = "$BASE_INDEX_SHA" ] || fail "Live public index is not exact successful V48-FIXED baseline."
[ "$(sha "$ASSETS/dgj-v48-premium.js")" = "$BASE_V48_JS_SHA" ] || fail "V48 premium JS baseline changed."
[ "$(sha "$ASSETS/dgj-v48-premium.css")" = "$BASE_V48_CSS_SHA" ] || fail "V48 premium CSS baseline changed."
[ "$(sha "$DIST/dgj-v46-employer.cjs")" = "$BASE_V46_MODULE_SHA" ] || fail "V46 employer backend baseline changed."
[ "$(sha "$ASSETS/dgj-v46-employer.js")" = "$BASE_V46_UI_SHA" ] || fail "V46 employer UI baseline changed."
[ "$(sha "$ASSETS/dgj-v46-employer.css")" = "$BASE_V46_CSS_SHA" ] || fail "V46 employer CSS baseline changed."
[ "$(sha "$DIST/dgj-v45-commercial.cjs")" = "$BASE_V45_MODULE_SHA" ] || fail "V45 commercial backend changed."
[ "$(sha "$ASSETS/dgj-v45-commercial.js")" = "$BASE_V45_UI_SHA" ] || fail "V45 commercial UI changed."
[ "$(sha "$ASSETS/dgj-v45-commercial.css")" = "$BASE_V45_CSS_SHA" ] || fail "V45 commercial CSS changed."
[ "$(sha "$ASSETS/dgj-admin-logo-v45.png")" = "$BASE_V45_LOGO_SHA" ] || fail "Admin/Employer brand logo changed."
[ "$(sha "$ASSETS/index-DGJ45auth-v43-youth.js")" = "$BASE_MAIN_SHA" ] || fail "V44 Youth SPA changed."
[ "$(sha "$PUBLIC/dgj-google-jobs-v27.js")" = "$BASE_GOOGLE_JOBS_SHA" ] || fail "Google Jobs companion changed."
[ "$(sha "$PUBLIC/devglobaljobs-social-share.png")" = "$BASE_SOCIAL_SHA" ] || fail "Social preview changed."
[ "$(sha "$PUBLIC/brand-contract.json")" = "$BASE_CONTRACT_SHA" ] || fail "Brand contract changed."
[ "$(sha "$PUBLIC/sw.js")" = "$BASE_SW_SHA" ] || fail "Service worker changed."
[ "$(sha "$PUBLIC/dgj-brand-contract-v27.js")" = "$BASE_BRAND_JS_SHA" ] || fail "Brand JS changed."
curl -fsS --max-time 20 http://127.0.0.1:8080/api/jobs/stats >/dev/null || fail "Local API unhealthy."
pm2 describe "$PM2_APP" | grep -q 'online' || fail "PM2 app not online."
echo "PASS: exact successful V48-FIXED baseline verified."

echo; echo "2/8 V49 PACKAGE + WORKFLOW VALIDATION"
[ "$(sha "$PAYLOAD/dist/dgj-v46-employer.cjs")" = "$NEW_V46_MODULE_SHA" ] || fail "V49 employer backend checksum mismatch."
[ "$(sha "$PAYLOAD/dist/public/assets/dgj-v46-employer.js")" = "$NEW_V46_UI_SHA" ] || fail "V49 employer UI checksum mismatch."
[ "$(sha "$PAYLOAD/dist/public/assets/dgj-v49-premium.js")" = "$NEW_V49_JS_SHA" ] || fail "V49 premium JS checksum mismatch."
[ "$(sha "$PAYLOAD/dist/public/assets/dgj-v49-premium.css")" = "$NEW_V49_CSS_SHA" ] || fail "V49 premium CSS checksum mismatch."
[ "$(sha "$PAYLOAD/dist/public/index.html")" = "$NEW_INDEX_SHA" ] || fail "V49 public index checksum mismatch."
node --check "$PAYLOAD/dist/dgj-v46-employer.cjs" >/dev/null
node --check "$PAYLOAD/dist/public/assets/dgj-v46-employer.js" >/dev/null
node --check "$PAYLOAD/dist/public/assets/dgj-v49-premium.js" >/dev/null
grep -Fq "app.post('/api/v49/employer/logo'" "$PAYLOAD/dist/dgj-v46-employer.cjs" || fail "Secure company-logo API missing."
grep -Fq 'content.prepend(box)' "$PAYLOAD/dist/public/assets/dgj-v49-premium.js" || fail "Safe Post a Job insertion missing."
if grep -Fq 'insertBefore' "$PAYLOAD/dist/public/assets/dgj-v49-premium.js"; then fail "Unsafe insertBefore found in V49 premium JS."; fi
if grep -Fq 'document.body.insertBefore(shell,root)' "$PAYLOAD/dist/public/assets/dgj-v46-employer.js"; then fail "Legacy Post a Job shell insertion still present."; fi
grep -Fq 'EMPLOYER PRODUCTS' "$PAYLOAD/dist/public/assets/dgj-v49-premium.js" || fail "Employer product catalogue missing."
grep -Fq 'dgj49-logo-manager' "$PAYLOAD/dist/public/assets/dgj-v49-premium.js" || fail "Company logo manager missing."
grep -Fq 'dgj49-payment-table' "$PAYLOAD/dist/public/assets/dgj-v49-premium.css" || fail "Payment table fix missing."
grep -Fq '@media(display-mode:standalone)' "$PAYLOAD/dist/public/assets/dgj-v49-premium.css" || fail "PWA standalone rules missing."
echo "PASS: V49 premium Employer/Admin workflow payload verified."

echo; echo "3/8 PROTECTED SERVER / COMMERCIAL / SEO CHECK"
[ ! -f "$PAYLOAD/dist/index.cjs" ] || fail "V49 must not replace the main server runtime."
for f in dgj-v45-commercial.cjs public/assets/dgj-v45-commercial.js public/assets/dgj-v45-commercial.css public/assets/dgj-v46-employer.css; do [ ! -f "$PAYLOAD/dist/$f" ] || fail "Protected file unexpectedly packaged: $f"; done
echo "PASS: main server, V45 commercial engine, V46 base CSS and protected SEO architecture are not replaced."

echo; echo "4/8 PRIVATE ROLLBACK BACKUP"
mkdir -p "$BACKUP"; chmod 700 "$BACKUP"
cp -af "$DIST/dgj-v46-employer.cjs" "$BACKUP/dgj-v46-employer.cjs"
cp -af "$ASSETS/dgj-v46-employer.js" "$BACKUP/dgj-v46-employer.js"
cp -af "$PUBLIC/index.html" "$BACKUP/index.html"
[ -f "$ASSETS/dgj-v49-premium.js" ] && cp -af "$ASSETS/dgj-v49-premium.js" "$BACKUP/dgj-v49-premium.js" || true
[ -f "$ASSETS/dgj-v49-premium.css" ] && cp -af "$ASSETS/dgj-v49-premium.css" "$BACKUP/dgj-v49-premium.css" || true
chmod -R go-rwx "$BACKUP"
echo "Backup: $BACKUP"
echo "PASS: rollback copy stored privately under /var/backups."

echo; echo "5/8 ATOMIC V49 INSTALL"
tmp_mod="$DIST/.dgj-v46-employer.cjs.v49.$$"; tmp_ui="$ASSETS/.dgj-v46-employer.js.v49.$$"; tmp_index="$PUBLIC/.index.html.v49.$$"; tmp_js="$ASSETS/.dgj-v49-premium.js.$$"; tmp_css="$ASSETS/.dgj-v49-premium.css.$$"
install -m 0644 "$PAYLOAD/dist/dgj-v46-employer.cjs" "$tmp_mod"
install -m 0644 "$PAYLOAD/dist/public/assets/dgj-v46-employer.js" "$tmp_ui"
install -m 0644 "$PAYLOAD/dist/public/index.html" "$tmp_index"
install -m 0644 "$PAYLOAD/dist/public/assets/dgj-v49-premium.js" "$tmp_js"
install -m 0644 "$PAYLOAD/dist/public/assets/dgj-v49-premium.css" "$tmp_css"
mv -f "$tmp_mod" "$DIST/dgj-v46-employer.cjs"
mv -f "$tmp_ui" "$ASSETS/dgj-v46-employer.js"
mv -f "$tmp_js" "$ASSETS/dgj-v49-premium.js"
mv -f "$tmp_css" "$ASSETS/dgj-v49-premium.css"
mv -f "$tmp_index" "$PUBLIC/index.html"
MUTATED=1
[ "$(sha "$DIST/dgj-v46-employer.cjs")" = "$NEW_V46_MODULE_SHA" ]
[ "$(sha "$ASSETS/dgj-v46-employer.js")" = "$NEW_V46_UI_SHA" ]
[ "$(sha "$ASSETS/dgj-v49-premium.js")" = "$NEW_V49_JS_SHA" ]
[ "$(sha "$ASSETS/dgj-v49-premium.css")" = "$NEW_V49_CSS_SHA" ]
[ "$(sha "$PUBLIC/index.html")" = "$NEW_INDEX_SHA" ]
echo "PASS: only reviewed Employer module/UI, public index and new V49 presentation assets installed."

echo; echo "6/8 PM2 RELOAD + ROUTE / SECURITY TESTS"
pm2 reload "$PM2_APP" --update-env
READY=0
for i in $(seq 1 30); do
  if curl -fsS --max-time 5 http://127.0.0.1:8080/api/jobs/stats >/dev/null 2>&1; then READY=1; echo "PASS: application ready after reload (attempt $i/30)."; break; fi
  sleep 2
done
[ "$READY" = "1" ] || { echo "FAIL: application did not become ready within 60 seconds."; false; }
EMP_CODE="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 20 http://127.0.0.1:8080/api/v46/employer/me || true)"
[ "$EMP_CODE" = "401" ] || { echo "FAIL: unauthenticated Employer API returned $EMP_CODE; expected 401."; false; }
LOGO_CODE="$(curl -sS -o /dev/null -w '%{http_code}' -X POST --max-time 20 http://127.0.0.1:8080/api/v49/employer/logo || true)"
[ "$LOGO_CODE" = "401" ] || { echo "FAIL: unauthenticated company-logo upload returned $LOGO_CODE; expected 401."; false; }
[ -d "$PUBLIC/uploads/employer-logos" ] || { echo "FAIL: secure employer-logo directory was not initialised."; false; }
H1="$BACKUP/v49-employer.headers"; CODE1="$(curl -sS -D "$H1" -o /dev/null -w '%{http_code}' --max-time 20 http://127.0.0.1:8080/employer || true)"; [ "$CODE1" = "302" ] || { echo "FAIL: signed-out /employer returned $CODE1; expected 302."; false; }; tr -d '\r' < "$H1" | grep -Fiq 'location: /employer/sign-in' || { echo "FAIL: Employer redirect target incorrect."; false; }
POST_FILE="$BACKUP/v49-post-signin.html"; POST_CODE="$(curl -sS -o "$POST_FILE" -w '%{http_code}' --max-time 20 http://127.0.0.1:8080/post-job || true)"; [ "$POST_CODE" = "200" ] || { echo "FAIL: signed-out /post-job returned $POST_CODE; expected 200 Employer Sign In."; false; }; grep -Fq 'Dev Global Jobs for Employers' "$POST_FILE" || { echo "FAIL: Employer Sign In branding missing from /post-job."; false; }
echo "PASS: Employer auth routes, company-logo endpoint protection and Post a Job server contract verified."

echo; echo "7/8 PROTECTED FILES + PUBLIC SECURITY CHECK"
[ "$(sha "$DIST/index.cjs")" = "$BASE_SERVER_SHA" ] || false
[ "$(sha "$DIST/dgj-v45-commercial.cjs")" = "$BASE_V45_MODULE_SHA" ] || false
[ "$(sha "$ASSETS/dgj-v45-commercial.js")" = "$BASE_V45_UI_SHA" ] || false
[ "$(sha "$ASSETS/dgj-v45-commercial.css")" = "$BASE_V45_CSS_SHA" ] || false
[ "$(sha "$ASSETS/dgj-v46-employer.css")" = "$BASE_V46_CSS_SHA" ] || false
[ "$(sha "$ASSETS/dgj-v48-premium.js")" = "$BASE_V48_JS_SHA" ] || false
[ "$(sha "$ASSETS/dgj-v48-premium.css")" = "$BASE_V48_CSS_SHA" ] || false
[ "$(sha "$ASSETS/index-DGJ45auth-v43-youth.js")" = "$BASE_MAIN_SHA" ] || false
[ "$(sha "$PUBLIC/dgj-google-jobs-v27.js")" = "$BASE_GOOGLE_JOBS_SHA" ] || false
[ "$(sha "$PUBLIC/devglobaljobs-social-share.png")" = "$BASE_SOCIAL_SHA" ] || false
[ "$(sha "$PUBLIC/brand-contract.json")" = "$BASE_CONTRACT_SHA" ] || false
[ "$(sha "$PUBLIC/sw.js")" = "$BASE_SW_SHA" ] || false
[ "$(sha "$PUBLIC/dgj-brand-contract-v27.js")" = "$BASE_BRAND_JS_SHA" ] || false
if find "$PUBLIC" -type f \( -iname '*payment-receipt*' -o -iname '*receipt*.pdf' -o -iname '*receipt*.jpg' -o -iname '*.sql' -o -iname '*.dump' -o -iname '.env*' -o -iname '*.zip' -o -iname '*.tar.gz' -o -iname '*.enc' \) -print -quit | grep -q .; then echo "Sensitive/archive-like file detected under public web root."; false; fi
echo "PASS: V45/SEO/Youth/social/service-worker files unchanged; no obvious sensitive archives exposed publicly."

echo; echo "8/8 FINAL ORIGIN + PUBLIC HEALTH"
curl -fsS --max-time 20 http://127.0.0.1:8080/assets/dgj-v49-premium.js?v=49.0.0 >/dev/null || false
curl -fsS --max-time 20 http://127.0.0.1:8080/assets/dgj-v49-premium.css?v=49.0.0 >/dev/null || false
curl -fsS --max-time 20 http://127.0.0.1:8080/assets/dgj-v46-employer.js?v=46.1.0 >/dev/null || false
curl -fsS --max-time 20 http://127.0.0.1:8080/ | grep -Fq 'dgj-v49-premium.js?v=49.0.0' || false
curl -fsS --max-time 20 http://127.0.0.1:8080/sitemap-index.xml | grep -q '<sitemapindex' || false
curl -fsS --max-time 20 https://devglobaljobs.com/ >/dev/null || false

echo; echo "============================================================"
echo "SUCCESS: V49 INTERNATIONAL EMPLOYER + ADMIN PREMIUM EXPERIENCE IS LIVE"
echo "============================================================"
echo "✓ Post a Job insertBefore DOM race removed from both premium layer and Employer shell"
echo "✓ Employer Dashboard visual system upgraded across all sections"
echo "✓ Billing payment history receives structured responsive columns"
echo "✓ Plans & Credits shows Regular / Featured / Premium Boost products plus existing plan credits"
echo "✓ Premium Boost page and secure payment/receipt modal upgraded"
echo "✓ Company Profile supports secure PNG/JPG/WebP company-logo upload up to 2 MB"
echo "✓ Company logo is stored as a public brand asset with content validation; no SVG/script uploads"
echo "✓ Admin login receives enterprise secure-administration presentation"
echo "✓ Admin dashboard readability, cards, tables, scrolling and custom commercial consoles upgraded"
echo "✓ Mobile / Android / iPhone / tablet / PWA standalone responsive safeguards included"
echo "✓ V45 prices, free quotas, payment verification, receipts, emails, Boost rules and plan codes unchanged"
echo "✓ Main server runtime / Google JobPosting / sitemap / V44 Youth / V42 social / service worker / brand lock unchanged"
echo "✓ Database change is additive only: nullable company_logo_url on dgj_v46_employer_profiles"
echo "Rollback backup: $BACKUP"
echo "============================================================"
trap - ERR INT TERM
