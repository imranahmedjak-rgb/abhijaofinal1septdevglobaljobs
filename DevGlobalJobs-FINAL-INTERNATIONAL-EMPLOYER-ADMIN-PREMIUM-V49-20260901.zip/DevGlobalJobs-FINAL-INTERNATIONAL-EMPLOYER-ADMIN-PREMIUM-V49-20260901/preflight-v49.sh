#!/usr/bin/env bash
set -Eeuo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
P="$HERE/payload"
fail(){ echo "SAFE STOP: $*" >&2; exit 1; }
[ -f "$HERE/PAYLOAD-SHA256SUMS.txt" ] || fail "Payload checksum manifest missing."
(cd "$HERE" && sha256sum -c PAYLOAD-SHA256SUMS.txt >/dev/null) || fail "Payload checksum verification failed."
node --check "$P/dist/dgj-v46-employer.cjs" >/dev/null || fail "Employer backend syntax invalid."
node --check "$P/dist/public/assets/dgj-v46-employer.js" >/dev/null || fail "Employer UI syntax invalid."
node --check "$P/dist/public/assets/dgj-v49-premium.js" >/dev/null || fail "V49 premium UI syntax invalid."
grep -Fq "app.post('/api/v49/employer/logo'" "$P/dist/dgj-v46-employer.cjs" || fail "Secure employer logo upload route missing."
grep -Fq 'company_logo_url' "$P/dist/dgj-v46-employer.cjs" || fail "Employer logo profile field missing."
grep -Fq 'V49_LOGO_MAX_BYTES=2*1024*1024' "$P/dist/dgj-v46-employer.cjs" || fail "Logo upload size control missing."
grep -Fq "Company logo must be a PNG, JPG or WebP image." "$P/dist/dgj-v46-employer.cjs" || fail "Logo content validation missing."
if grep -Fq 'document.body.insertBefore(shell,root)' "$P/dist/public/assets/dgj-v46-employer.js"; then fail "Legacy risky Post a Job shell insertion still present."; fi
if grep -Fq 'insertBefore' "$P/dist/public/assets/dgj-v49-premium.js"; then fail "V49 premium layer must not use insertBefore."; fi
grep -Fq 'content.prepend(box)' "$P/dist/public/assets/dgj-v49-premium.js" || fail "Safe Post a Job intro insertion missing."
grep -Fq 'EMPLOYER PRODUCTS' "$P/dist/public/assets/dgj-v49-premium.js" || fail "Employer product catalogue missing."
grep -Fq "Regular Job" "$P/dist/public/assets/dgj-v49-premium.js" || fail "Regular product missing."
grep -Fq "Featured Job" "$P/dist/public/assets/dgj-v49-premium.js" || fail "Featured product missing."
grep -Fq "Premium Boost" "$P/dist/public/assets/dgj-v49-premium.js" || fail "Premium Boost product missing."
grep -Fq 'dgj49-logo-manager' "$P/dist/public/assets/dgj-v49-premium.js" || fail "Employer company-logo manager missing."
grep -Fq 'dgj49-payment-table' "$P/dist/public/assets/dgj-v49-premium.css" || fail "Payment history layout fix missing."
grep -Fq 'dgj49-admin-section' "$P/dist/public/assets/dgj-v49-premium.css" || fail "Admin dashboard premium section styling missing."
grep -Fq '@media(display-mode:standalone)' "$P/dist/public/assets/dgj-v49-premium.css" || fail "PWA standalone responsive rules missing."
grep -Fq '@media(max-width:760px)' "$P/dist/public/assets/dgj-v49-premium.css" || fail "Mobile responsive rules missing."
grep -Fq 'dgj-v49-premium.css?v=49.0.0' "$P/dist/public/index.html" || fail "V49 CSS not wired into public index."
grep -Fq 'dgj-v49-premium.js?v=49.0.0' "$P/dist/public/index.html" || fail "V49 JS not wired into public index."
grep -Fq 'dgj-v46-employer.js?v=46.1.0' "$P/dist/public/index.html" || fail "Employer UI cache-bust missing."
if grep -Fq 'dgj-v48-premium.js?v=48.0.0' "$P/dist/public/index.html"; then fail "Old V48 JS still referenced by index."; fi
echo "PASS: V49 Post a Job DOM fix, premium Employer Workspace, products, Boost, billing, company-logo profile, Admin presentation and mobile/PWA safeguards verified."
