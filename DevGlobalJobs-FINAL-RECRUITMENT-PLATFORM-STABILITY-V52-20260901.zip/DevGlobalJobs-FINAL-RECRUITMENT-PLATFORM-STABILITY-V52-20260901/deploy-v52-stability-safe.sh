#!/usr/bin/env bash
set -Eeuo pipefail
APP="${DGJ_APP_ROOT:-/var/www/devglobaljobs}"
DIST="$APP/dist"
PUBLIC="$DIST/public"
ORIGIN="${DGJ_ORIGIN_URL:-http://127.0.0.1:8080}"
PUBLIC_URL="${DGJ_PUBLIC_URL:-https://devglobaljobs.com}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$ROOT/payload"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_ROOT="${DGJ_BACKUP_ROOT:-/var/backups}"
BACKUP="$BACKUP_ROOT/devglobaljobs-recruitment-stability-v52-$STAMP"
MUTATED=0
DONE=0

# Exact successful V51-FIXED2 live baseline.
OLD_SERVER_SHA="754afef80c982fd75e6373d839893858a85f42909589da5ffd29d59c2fdbcd0c"
OLD_V45_BACKEND_SHA="604bc9cdc6f60ec989bf9582558dbe5b470018e3e1ffb631a9866763d8859dfe"
OLD_V46_BACKEND_SHA="bc5c4f4088cc434aabe5acfba0c9b521228330775799c55c2e941a95f05b205e"
OLD_V51_BACKEND_SHA="904fa113528a1cde41dcaade4bbca5dc40083390f1e800bc490279f211e6235e"
OLD_V51_EMPLOYER_JS_SHA="dba27db99edc578ffeea08efb29edfea8af3b194edf6a4d130d150f0aa971ef6"
OLD_V51_RECRUITMENT_JS_SHA="f59c3d0b8096dcf2ec6921e395151e7f16ff8c1e6fe8c4dae15b22d6fa98b766"
OLD_V51_RECRUITMENT_CSS_SHA="7392d2c6f73cc67d3d9c2cb8a93b5a5c0a4f923438bd56bd0967855d4bc3b0f0"
OLD_INDEX_SHA="335ed46c93b624e0ad2558de7683e91e64f564259838685147ef9f3f65b233b7"

# Protected architecture that V52 must leave byte-for-byte unchanged.
V45_UI_JS_SHA="a52126b670737e30dd6f929fb6f901d2e66bf99f899d65a22199ce3e0952a801"
V45_UI_CSS_SHA="cd3038190e9fc212058fd53bdf506b6bd28661764fdb083605e589d54819dfe7"
V49_JS_SHA="d7a9fff8892ac44e9f38a72fab121550d03ea3d9fc3557c29db251c1fdd3492f"
V49_CSS_SHA="5929d5a9edb36e5670dadf0511508e945751b510dbb20fead09116f5e1c41e2f"
YOUTH_SHA="ff420f2b6b88f06f5a9f6c9e3bc2ae88b456bbca5bb6a76b3047992874a909df"
GOOGLE_JOBS_SHA="efd02864b5ea0703465ab7d62a6b8dc43d7a48e0ea074082a45f6a7adc23ddf6"
SOCIAL_SHA="528878c345ddf89bde59041513d2b406fb1c8bcb786ee9874413247a6a6cbd92"
BRAND_SHA="00e06a8e7592a5aff18fcfa21492b43a2ad513c46a473d45f45367c7765295b4"
SW_SHA="7f6986e064891c43437df7f35fd4c2a7050d1ce82bd0120b12afb7e9fa1733f3"

NEW_JS_SHA="77531cfb660d72a3153e94738368929665d2920c506f4ad1129959df94c631bc"
NEW_CSS_SHA="830bdb46197607c1f433446be33267499726792dfd308baae90ea7a1a7493d60"
NEW_INDEX_SHA="c22148523ad9d9b901eba0a2a539106332ef82a83b0e2de046f6fc72668fcdb9"

sha(){ sha256sum "$1" | awk '{print $1}'; }
rollback(){
  trap - ERR
  MUTATED=0
  set +e
  echo
  echo "ROLLBACK: restoring exact pre-V52 frontend files..."
  if [ -d "$BACKUP" ]; then
    [ -f "$BACKUP/dgj-v51-recruitment.js" ] && cp -a "$BACKUP/dgj-v51-recruitment.js" "$PUBLIC/assets/dgj-v51-recruitment.js"
    [ -f "$BACKUP/dgj-v51-recruitment.css" ] && cp -a "$BACKUP/dgj-v51-recruitment.css" "$PUBLIC/assets/dgj-v51-recruitment.css"
    [ -f "$BACKUP/index.html" ] && cp -a "$BACKUP/index.html" "$PUBLIC/index.html"
  fi
  echo "ROLLBACK COMPLETE. V51 backend/database were never changed by V52."
}
fail(){
  echo
  echo "============================================================"
  echo "SAFE STOP: $*"
  echo "============================================================"
  if [ "$MUTATED" -eq 1 ] && [ "$DONE" -eq 0 ]; then rollback; fi
  exit 1
}
onerr(){
  code=$?
  if [ "$MUTATED" -eq 1 ] && [ "$DONE" -eq 0 ]; then rollback; fi
  exit "$code"
}
trap onerr ERR

for c in sha256sum curl node python3 install mv cp mkdir grep find; do command -v "$c" >/dev/null 2>&1 || fail "Required command missing: $c"; done
[ -d "$APP" ] && [ -d "$PUBLIC/assets" ] || fail "Dev Global Jobs production path is missing."

echo "============================================================"
echo "DEV GLOBAL JOBS V52"
echo "RECRUITMENT PLATFORM STABILITY RELEASE"
echo "EMPLOYER READY HANDSHAKE · PROFILE SINGLETON · EASY APPLY SINGLETON"
echo "============================================================"

echo
echo "1/8 EXACT SUCCESSFUL V51-FIXED2 BASELINE + HEALTH"
HEALTH="$ROOT/.v52-health-$STAMP.json"
curl -fsS --max-time 15 "$ORIGIN/api/jobs/stats" -o "$HEALTH" || fail "Current application origin is not healthy."
[ "$(sha "$DIST/index.cjs")" = "$OLD_SERVER_SHA" ] || fail "Main server runtime differs from the reviewed V51 baseline."
[ "$(sha "$DIST/dgj-v45-commercial.cjs")" = "$OLD_V45_BACKEND_SHA" ] || fail "V45 commercial backend differs from V51 baseline."
[ "$(sha "$DIST/dgj-v46-employer.cjs")" = "$OLD_V46_BACKEND_SHA" ] || fail "Employer backend differs from V51 baseline."
[ "$(sha "$DIST/dgj-v51-recruitment.cjs")" = "$OLD_V51_BACKEND_SHA" ] || fail "V51 recruitment backend differs from baseline."
[ "$(sha "$PUBLIC/assets/dgj-v51-employer.js")" = "$OLD_V51_EMPLOYER_JS_SHA" ] || fail "V51 Employer frontend differs from baseline."
[ "$(sha "$PUBLIC/assets/dgj-v51-recruitment.js")" = "$OLD_V51_RECRUITMENT_JS_SHA" ] || fail "V51 recruitment frontend differs from baseline."
[ "$(sha "$PUBLIC/assets/dgj-v51-recruitment.css")" = "$OLD_V51_RECRUITMENT_CSS_SHA" ] || fail "V51 recruitment CSS differs from baseline."
[ "$(sha "$PUBLIC/index.html")" = "$OLD_INDEX_SHA" ] || fail "Public index differs from exact V51 baseline."
echo "PASS: exact successful V51-FIXED2 baseline verified."

echo
echo "2/8 V52 PACKAGE + REGRESSION PREFLIGHT"
cd "$ROOT"
./preflight-v52.sh || fail "V52 package preflight failed."
[ "$(sha "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.js")" = "$NEW_JS_SHA" ] || fail "V52 JS package hash mismatch."
[ "$(sha "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.css")" = "$NEW_CSS_SHA" ] || fail "V52 CSS package hash mismatch."
[ "$(sha "$PAYLOAD/dist/public/index.html")" = "$NEW_INDEX_SHA" ] || fail "V52 index package hash mismatch."
echo "PASS: V52 stability payload verified."

echo
echo "3/8 PROTECTED COMMERCIAL / SEO / BRAND BYTE CHECK"
[ "$(sha "$PUBLIC/assets/dgj-v45-commercial.js")" = "$V45_UI_JS_SHA" ] || fail "V45 commercial UI changed unexpectedly."
[ "$(sha "$PUBLIC/assets/dgj-v45-commercial.css")" = "$V45_UI_CSS_SHA" ] || fail "V45 commercial CSS changed unexpectedly."
[ "$(sha "$PUBLIC/assets/dgj-v49-premium.js")" = "$V49_JS_SHA" ] || fail "V49 premium JS changed unexpectedly."
[ "$(sha "$PUBLIC/assets/dgj-v49-premium.css")" = "$V49_CSS_SHA" ] || fail "V49 premium CSS changed unexpectedly."
[ "$(sha "$PUBLIC/assets/index-DGJ45auth-v43-youth.js")" = "$YOUTH_SHA" ] || fail "Youth/auth SPA changed unexpectedly."
[ "$(sha "$PUBLIC/dgj-google-jobs-v27.js")" = "$GOOGLE_JOBS_SHA" ] || fail "Google Jobs asset changed unexpectedly."
[ "$(sha "$PUBLIC/devglobaljobs-social-share.png")" = "$SOCIAL_SHA" ] || fail "Social preview asset changed unexpectedly."
[ "$(sha "$PUBLIC/brand-contract.json")" = "$BRAND_SHA" ] || fail "Brand contract changed unexpectedly."
[ "$(sha "$PUBLIC/sw.js")" = "$SW_SHA" ] || fail "Service worker changed unexpectedly."
echo "PASS: protected commercial, SEO, Youth, social and brand files verified."

echo
echo "4/8 PRIVATE ROLLBACK BACKUP"
mkdir -p "$BACKUP"
chmod 700 "$BACKUP"
cp -a "$PUBLIC/assets/dgj-v51-recruitment.js" "$BACKUP/dgj-v51-recruitment.js"
cp -a "$PUBLIC/assets/dgj-v51-recruitment.css" "$BACKUP/dgj-v51-recruitment.css"
cp -a "$PUBLIC/index.html" "$BACKUP/index.html"
sha256sum "$BACKUP"/* > "$BACKUP/SHA256SUMS.txt"
chmod 600 "$BACKUP"/*
echo "Backup: $BACKUP"
echo "PASS: all touched frontend files backed up privately."

echo
echo "5/8 ATOMIC V52 INSTALL"
install_atomic(){
  local src="$1"
  local dst="$2"
  local mode="${3:-0644}"
  local tmp
  tmp="${dst}.v52.$$"
  install -m "$mode" "$src" "$tmp"
  mv -f "$tmp" "$dst"
}
MUTATED=1
install_atomic "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.js" "$PUBLIC/assets/dgj-v51-recruitment.js"
install_atomic "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.css" "$PUBLIC/assets/dgj-v51-recruitment.css"
install_atomic "$PAYLOAD/dist/public/index.html" "$PUBLIC/index.html"
[ "$(sha "$PUBLIC/assets/dgj-v51-recruitment.js")" = "$NEW_JS_SHA" ] || fail "Installed V52 JS hash mismatch."
[ "$(sha "$PUBLIC/assets/dgj-v51-recruitment.css")" = "$NEW_CSS_SHA" ] || fail "Installed V52 CSS hash mismatch."
[ "$(sha "$PUBLIC/index.html")" = "$NEW_INDEX_SHA" ] || fail "Installed V52 index hash mismatch."
echo "PASS: only three reviewed frontend files installed."

echo
echo "6/8 ORIGIN ASSET + V51 API CONTRACT"
HOME="$BACKUP/v52-origin-home.html"
JSFILE="$BACKUP/v52-origin-js"
CSSFILE="$BACKUP/v52-origin-css"
CFG="$BACKUP/v52-config.json"
curl -fsS --max-time 20 "$ORIGIN/" -o "$HOME" || fail "Origin homepage failed after V52 install."
grep -Fq '/assets/dgj-v51-recruitment.js?v=52.0.0' "$HOME" || fail "Origin homepage does not reference V52 recruitment JS."
grep -Fq '/assets/dgj-v51-recruitment.css?v=52.0.0' "$HOME" || fail "Origin homepage does not reference V52 recruitment CSS."
curl -fsS --max-time 20 "$ORIGIN/assets/dgj-v51-recruitment.js?v=52.0.0" -o "$JSFILE" || fail "Origin V52 JS asset failed."
curl -fsS --max-time 20 "$ORIGIN/assets/dgj-v51-recruitment.css?v=52.0.0" -o "$CSSFILE" || fail "Origin V52 CSS asset failed."
[ "$(sha "$JSFILE")" = "$NEW_JS_SHA" ] || fail "Origin is not serving exact V52 JS bytes."
[ "$(sha "$CSSFILE")" = "$NEW_CSS_SHA" ] || fail "Origin is not serving exact V52 CSS bytes."
curl -fsS --max-time 20 "$ORIGIN/api/v51/config" -o "$CFG" || fail "V51 recruitment config endpoint failed."
python3 - "$CFG" <<'PY'
import json,sys
x=json.load(open(sys.argv[1]))
assert x.get('version')=='51.0.0',x
assert x.get('retentionDays')==180,x
assert set(x.get('applicationMethods') or [])=={'dgj','email'},x
print('PASS: V51 backend contract retained')
PY
for endpoint in /api/v51/candidate/applications /api/v51/employer/applications /api/v46/employer/me; do
  code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 "$ORIGIN$endpoint" || true)"
  [ "$code" = "401" ] || fail "Unauthenticated protection changed for $endpoint (HTTP $code)."
done
echo "PASS: V52 assets and protected V51 API contract verified at origin."

echo
echo "7/8 POST-INSTALL PROTECTED FILE CHECK"
[ "$(sha "$DIST/index.cjs")" = "$OLD_SERVER_SHA" ] || fail "Main server changed during V52 deployment."
[ "$(sha "$DIST/dgj-v45-commercial.cjs")" = "$OLD_V45_BACKEND_SHA" ] || fail "V45 backend changed during V52 deployment."
[ "$(sha "$DIST/dgj-v46-employer.cjs")" = "$OLD_V46_BACKEND_SHA" ] || fail "V46 backend changed during V52 deployment."
[ "$(sha "$DIST/dgj-v51-recruitment.cjs")" = "$OLD_V51_BACKEND_SHA" ] || fail "V51 backend changed during V52 deployment."
[ "$(sha "$PUBLIC/assets/dgj-v51-employer.js")" = "$OLD_V51_EMPLOYER_JS_SHA" ] || fail "Employer JS changed during V52 deployment."
[ "$(sha "$PUBLIC/assets/dgj-v49-premium.js")" = "$V49_JS_SHA" ] || fail "V49 premium JS changed during V52 deployment."
[ "$(sha "$PUBLIC/dgj-google-jobs-v27.js")" = "$GOOGLE_JOBS_SHA" ] || fail "Google Jobs changed during V52 deployment."
[ "$(sha "$PUBLIC/sw.js")" = "$SW_SHA" ] || fail "Service worker changed during V52 deployment."
echo "PASS: server/backend/commercial/SEO assets remain byte-for-byte unchanged."

echo
echo "8/8 FINAL PUBLIC HEALTH"
curl -fsS --max-time 20 "$PUBLIC_URL/" -o "$BACKUP/v52-public-home.html" || echo "WARNING: public CDN fetch unavailable; origin validation already passed."
curl -fsS --max-time 20 "$PUBLIC_URL/api/jobs/stats" -o "$BACKUP/v52-public-health.json" || echo "WARNING: public API fetch unavailable; origin validation already passed."
DONE=1
trap - ERR

echo
echo "============================================================"
echo "SUCCESS: V52 RECRUITMENT PLATFORM STABILITY RELEASE IS LIVE"
echo "============================================================"
echo "✓ Employer Post a Job releases the legacy loading mask only after the real form is ready"
echo "✓ Candidate Profile renders exactly one My Applications / Application Tracker section"
echo "✓ Application Tracker mounts before My CV Formats when available"
echo "✓ Public Easy Apply is singleton-safe during delayed API / DOM mutation activity"
echo "✓ Email Easy Apply remains non-withdrawable; DGJ-managed withdrawal rules preserved"
echo "✓ Candidate tracker mobile width is contained"
echo "✓ V51 ATS, applications, CV downloads, reports and 180-day retention backend unchanged"
echo "✓ V45 commercial system, V49 premium UI, Google Jobs, sitemap architecture, Youth, social, service worker and brand contract unchanged"
echo "✓ No database migration and no PM2 reload performed"
echo "Rollback backup: $BACKUP"
echo "============================================================"
