#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$ROOT/payload"
fail(){ echo "FAIL: $*" >&2; exit 1; }
for c in sha256sum node grep find python3 bash; do command -v "$c" >/dev/null 2>&1 || fail "Required command missing: $c"; done
cd "$ROOT"
sha256sum -c PAYLOAD-SHA256SUMS.txt >/dev/null || fail "Payload checksum verification failed."
mapfile -t files < <(find payload -type f | sort)
[ "${#files[@]}" -eq 3 ] || fail "V52 must contain exactly three production payload files; found ${#files[@]}."
[ -f "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.js" ] || fail "Recruitment JS missing."
[ -f "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.css" ] || fail "Recruitment CSS missing."
[ -f "$PAYLOAD/dist/public/index.html" ] || fail "Public index missing."
[ ! -e "$PAYLOAD/dist/index.cjs" ] || fail "Main server runtime must not be in V52 payload."
[ ! -e "$PAYLOAD/dist/dgj-v51-recruitment.cjs" ] || fail "V51 backend must not be in V52 payload."
[ ! -e "$PAYLOAD/dist/dgj-v46-employer.cjs" ] || fail "Employer backend must not be in V52 payload."
[ ! -e "$PAYLOAD/dist/dgj-v45-commercial.cjs" ] || fail "V45 commercial backend must not be in V52 payload."
node --check "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.js" >/dev/null || fail "Recruitment JS syntax failed."
bash -n "$ROOT/preflight-v52.sh" || fail "V52 preflight Bash syntax failed."
bash -n "$ROOT/deploy-v52-stability-safe.sh" || fail "V52 deploy Bash syntax failed."
if grep -Fq 'local src="$1" dst="$2"' "$ROOT/deploy-v52-stability-safe.sh"; then fail "Unsafe set -u local assignment pattern found in deployer."; fi
if grep -Eq 'curl[^\n]*\|[^\n]*grep[^\n]*-[^ ]*q' "$ROOT/deploy-v52-stability-safe.sh"; then fail "Unsafe curl|grep -q pipefail validator found in deployer."; fi
python3 - "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.js" "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.css" "$PAYLOAD/dist/public/index.html" <<'PY'
from pathlib import Path
import sys
js,css,idx=[Path(x).read_text() for x in sys.argv[1:]]
required_js=[
    'window.__DGJ_V52_STABILITY__=true',
    'easyApplyBusyJob',
    'candidateAppsBusy',
    'candidateAppsGeneration',
    'cleanupCandidateApplicationDuplicates',
    'profileApplicationMount',
    'releaseLegacyEmployerTransition',
    "document.documentElement.classList.add('dgj52-employer-ready')",
    "m.before.before(section)",
    "cannot be withdrawn through Dev Global Jobs",
]
for marker in required_js:
    if marker not in js: raise SystemExit(f'missing JS marker: {marker}')
if 'insertBefore' in js:
    raise SystemExit('unsafe insertBefore must not appear in the V52 recruitment JS')
if js.count("id='dgj51-my-applications'") or js.count('id="dgj51-my-applications"'):
    # The ID is assigned through section.id, not static duplicated markup.
    pass
for marker in ['html.dgj52-employer-ready.dgj49-route-boot','V52 candidate tracker containment','overflow-wrap:anywhere']:
    if marker not in css: raise SystemExit(f'missing CSS marker: {marker}')
if '/assets/dgj-v51-recruitment.js?v=52.0.0' not in idx: raise SystemExit('V52 recruitment JS cache-bust missing')
if '/assets/dgj-v51-recruitment.css?v=52.0.0' not in idx: raise SystemExit('V52 recruitment CSS cache-bust missing')
if '/assets/dgj-v49-premium.js?v=49.0.0' not in idx: raise SystemExit('V49 premium JS reference changed unexpectedly')
if '/assets/dgj-v51-employer.js?v=51.0.0' not in idx: raise SystemExit('V51 employer JS reference changed unexpectedly')
if '/assets/dgj-v51-recruitment.js?v=51.0.0' in idx or '/assets/dgj-v51-recruitment.css?v=51.0.0' in idx:
    raise SystemExit('stale V51 recruitment asset cache-bust remains')
print('PASS semantics')
PY
python3 - "$ROOT/deploy-v52-stability-safe.sh" <<'PY'
from pathlib import Path
import sys
lines=Path(sys.argv[1]).read_text().splitlines()
mut=next((i for i,x in enumerate(lines) if x.strip()=='MUTATED=1'),None)
first=next((i for i,x in enumerate(lines) if x.strip().startswith('install_atomic "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.js"')),None)
if mut is None or first is None or mut>=first: raise SystemExit('rollback guard is not armed before first production replacement')
text='\n'.join(lines)
if 'trap - ERR' not in text or 'ROLLBACK COMPLETE' not in text: raise SystemExit('rollback hardening markers missing')
print('PASS deployer safety semantics')
PY

echo "PASS: V52 employer transition, Candidate Profile singleton, public Easy Apply singleton and mobile containment preflight verified."
