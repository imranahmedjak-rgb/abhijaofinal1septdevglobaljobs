Dev Global Jobs — V52 Recruitment Platform Stability Release
Date: 2026-09-01

Baseline
- Requires exact successful V51-FIXED2 production frontend/backend baseline.
- Refuses to deploy if reviewed V51 core or protected SEO/commercial assets differ.

Why V52 exists
1. Employer Post a Job could remain covered by the legacy V49 "Opening job publishing" transition even after the V51 shell/form was ready.
2. Candidate Profile could show several identical My Applications / Application Tracker sections because the old async injector could be started multiple times by MutationObserver events before its API request completed.
3. The public Easy Apply injector used the same pre-await singleton check pattern and has therefore been hardened before it becomes a visible duplicate-button regression.

What V52 changes
- Adds an explicit ready handshake from V51 recruitment UI to the older V49 route-mask layer.
- Removes dgj49-route-boot only when the employer shell, mounted root, submit control and form are actually present.
- Adds a CSS fail-safe so a ready Employer Workspace cannot remain hidden by the old boot-mask selector.
- Serializes Candidate My Applications loading with a busy/generation guard.
- Removes any duplicate tracker nodes and mounts one canonical tracker.
- Mounts the tracker before My CV Formats where available.
- Keeps Email Easy Apply non-withdrawable and DGJ Easy Apply withdrawable when still active.
- Serializes public Easy Apply discovery/injection per job.
- Adds mobile containment for tracker cards/timeline.
- Cache-busts only the V51 recruitment JS/CSS to v52.0.0.

Deployment
Run ./preflight-v52.sh first, then ./deploy-v52-stability-safe.sh.
The deployer backs up all touched files privately under /var/backups before mutation and rolls them back automatically on post-install validation failure.
