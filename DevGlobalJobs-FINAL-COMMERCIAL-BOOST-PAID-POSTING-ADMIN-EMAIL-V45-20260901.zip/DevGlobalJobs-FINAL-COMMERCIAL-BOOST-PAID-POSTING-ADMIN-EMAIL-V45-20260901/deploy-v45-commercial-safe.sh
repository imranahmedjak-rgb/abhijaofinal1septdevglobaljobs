#!/usr/bin/env bash
set -Eeuo pipefail

APP="/var/www/devglobaljobs"
DIST="$APP/dist"
PUBLIC="$DIST/public"
ASSETS="$PUBLIC/assets"
PM2_APP="devglobaljobs"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/var/backups/devglobaljobs-commercial-v45-${STAMP}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$HERE/payload"

# Exact current production baseline: V42 server + V44 homepage cache-bust.
BASE_SERVER_SHA="5fd0904e15390aaefbe91832f2fb27589cf91ee8125ab24e85b37654e0d51dd6"
BASE_INDEX_SHA="a69ddbc55b2048cf0a4dc2f942a24fff273d6326a6b60446cc88983074b4afce"
BASE_MAIN_SHA="ff420f2b6b88f06f5a9f6c9e3bc2ae88b456bbca5bb6a76b3047992874a909df"
BASE_GOOGLE_JOBS_SHA="efd02864b5ea0703465ab7d62a6b8dc43d7a48e0ea074082a45f6a7adc23ddf6"
BASE_SOCIAL_SHA="528878c345ddf89bde59041513d2b406fb1c8bcb786ee9874413247a6a6cbd92"
BASE_CONTRACT_SHA="00e06a8e7592a5aff18fcfa21492b43a2ad513c46a473d45f45367c7765295b4"
BASE_SW_SHA="7f6986e064891c43437df7f35fd4c2a7050d1ce82bd0120b12afb7e9fa1733f3"
BASE_BRAND_JS_SHA="c65297262b99483d6fa87e4a2e469417e98592162329d1f1646dfab91e02fdd4"

NEW_SERVER_SHA="14013f06f03996b0818714f4572f12409d3c345445a0579c82ade920b56df0ef"
NEW_MODULE_SHA="d8ba3950fc169dfaa94fa061b466dd3152bc969a375b6e31ed87f7155af09b0f"
NEW_INDEX_SHA="cdf2cea722c780d11d9a99234da97079409a8e9fe4843ad04f2fb716ba8c160f"
NEW_UI_SHA="a52126b670737e30dd6f929fb6f901d2e66bf99f899d65a22199ce3e0952a801"
NEW_CSS_SHA="cd3038190e9fc212058fd53bdf506b6bd28661764fdb083605e589d54819dfe7"
NEW_LOGO_SHA="66d36152a4de7a1f2d7270a3901ebc204cc4592ca66f93a2370a6110d4eb05ea"

MUTATED=0

sha(){ sha256sum "$1" | awk '{print $1}'; }
fail(){
  echo
  echo "============================================================"
  echo "SAFE STOP: $*"
  echo "============================================================"
  exit 1
}

rollback(){
  local rc=$?
  if [ "$MUTATED" = "1" ]; then
    echo
    echo "ROLLBACK: restoring exact pre-V45 production files..."
    set +e
    [ -f "$BACKUP/index.cjs" ] && cp -af "$BACKUP/index.cjs" "$DIST/index.cjs"
    [ -f "$BACKUP/index.html" ] && cp -af "$BACKUP/index.html" "$PUBLIC/index.html"
    if [ -f "$BACKUP/dgj-v45-commercial.cjs" ]; then cp -af "$BACKUP/dgj-v45-commercial.cjs" "$DIST/dgj-v45-commercial.cjs"; else rm -f "$DIST/dgj-v45-commercial.cjs"; fi
    if [ -f "$BACKUP/dgj-v45-commercial.js" ]; then cp -af "$BACKUP/dgj-v45-commercial.js" "$ASSETS/dgj-v45-commercial.js"; else rm -f "$ASSETS/dgj-v45-commercial.js"; fi
    if [ -f "$BACKUP/dgj-v45-commercial.css" ]; then cp -af "$BACKUP/dgj-v45-commercial.css" "$ASSETS/dgj-v45-commercial.css"; else rm -f "$ASSETS/dgj-v45-commercial.css"; fi
    if [ -f "$BACKUP/dgj-admin-logo-v45.png" ]; then cp -af "$BACKUP/dgj-admin-logo-v45.png" "$ASSETS/dgj-admin-logo-v45.png"; else rm -f "$ASSETS/dgj-admin-logo-v45.png"; fi
    pm2 reload "$PM2_APP" --update-env >/dev/null 2>&1 || true
    echo "ROLLBACK COMPLETE. Existing site files restored."
    echo "Note: additive dgj_v45_* database tables may remain if they were already created; existing jobs/users/applications are not deleted by this deployer."
    set -e
  fi
  exit "$rc"
}
trap rollback ERR INT TERM

printf '%s\n' \
"============================================================" \
"DEV GLOBAL JOBS V45" \
"COMMERCIAL POSTING + PREMIUM BOOST + ADMIN PROMOTION CENTRE" \
"============================================================"

[ "$(id -u)" = "0" ] || fail "Run this deployer as root."
[ -d "$APP" ] || fail "Application directory missing: $APP"
[ -d "$ASSETS" ] || fail "Public assets directory missing."
[ -f "$DIST/index.cjs" ] || fail "Live server runtime missing."
[ -f "$PUBLIC/index.html" ] || fail "Live public index missing."
[ -f "$ASSETS/index-DGJ45auth-v43-youth.js" ] || fail "V44 active youth bundle missing."

for c in sha256sum node curl pm2 install grep mkdir cp mv chmod find stat; do command -v "$c" >/dev/null 2>&1 || fail "Required command missing: $c"; done


echo
echo "1/8 EXACT V44 LIVE BASELINE + HEALTH"
[ "$(sha "$DIST/index.cjs")" = "$BASE_SERVER_SHA" ] || fail "Server runtime is not the exact reviewed V42/V44 baseline. Nothing changed."
[ "$(sha "$PUBLIC/index.html")" = "$BASE_INDEX_SHA" ] || fail "Public index is not the exact successful V44 baseline. Nothing changed."
[ "$(sha "$ASSETS/index-DGJ45auth-v43-youth.js")" = "$BASE_MAIN_SHA" ] || fail "Active V44 youth SPA bundle changed. Nothing changed."
[ "$(sha "$PUBLIC/dgj-google-jobs-v27.js")" = "$BASE_GOOGLE_JOBS_SHA" ] || fail "Google Jobs companion changed."
[ "$(sha "$PUBLIC/devglobaljobs-social-share.png")" = "$BASE_SOCIAL_SHA" ] || fail "V42 social preview asset changed."
[ "$(sha "$PUBLIC/brand-contract.json")" = "$BASE_CONTRACT_SHA" ] || fail "Brand contract changed."
[ "$(sha "$PUBLIC/sw.js")" = "$BASE_SW_SHA" ] || fail "Service worker changed."
[ "$(sha "$PUBLIC/dgj-brand-contract-v27.js")" = "$BASE_BRAND_JS_SHA" ] || fail "Brand lock JS changed."
curl -fsS --max-time 20 http://127.0.0.1:8080/api/jobs/stats >/dev/null || fail "Local API unhealthy before deployment."
pm2 describe "$PM2_APP" | grep -q 'online' || fail "PM2 app is not online before deployment."
echo "PASS: exact current production baseline and health verified."


echo
echo "2/8 PACKAGE INTEGRITY + FEATURE VALIDATION"
[ -f "$PAYLOAD/dist/index.cjs" ] || fail "V45 server payload missing."
[ -f "$PAYLOAD/dist/dgj-v45-commercial.cjs" ] || fail "V45 commercial module missing."
[ -f "$PAYLOAD/dist/public/index.html" ] || fail "V45 index payload missing."
[ -f "$PAYLOAD/dist/public/assets/dgj-v45-commercial.js" ] || fail "V45 UI payload missing."
[ -f "$PAYLOAD/dist/public/assets/dgj-v45-commercial.css" ] || fail "V45 CSS payload missing."
[ -f "$PAYLOAD/dist/public/assets/dgj-admin-logo-v45.png" ] || fail "V45 admin logo missing."

[ "$(sha "$PAYLOAD/dist/index.cjs")" = "$NEW_SERVER_SHA" ] || fail "Reviewed V45 server checksum mismatch."
[ "$(sha "$PAYLOAD/dist/dgj-v45-commercial.cjs")" = "$NEW_MODULE_SHA" ] || fail "Reviewed V45 module checksum mismatch."
[ "$(sha "$PAYLOAD/dist/public/index.html")" = "$NEW_INDEX_SHA" ] || fail "Reviewed V45 index checksum mismatch."
[ "$(sha "$PAYLOAD/dist/public/assets/dgj-v45-commercial.js")" = "$NEW_UI_SHA" ] || fail "Reviewed V45 UI checksum mismatch."
[ "$(sha "$PAYLOAD/dist/public/assets/dgj-v45-commercial.css")" = "$NEW_CSS_SHA" ] || fail "Reviewed V45 CSS checksum mismatch."
[ "$(sha "$PAYLOAD/dist/public/assets/dgj-admin-logo-v45.png")" = "$NEW_LOGO_SHA" ] || fail "Reviewed V45 logo checksum mismatch."

node --check "$PAYLOAD/dist/index.cjs" >/dev/null
node --check "$PAYLOAD/dist/dgj-v45-commercial.cjs" >/dev/null
node --check "$PAYLOAD/dist/public/assets/dgj-v45-commercial.js" >/dev/null

grep -Fq 'V45_PAID_REVIEW_REQUIRED' "$PAYLOAD/dist/dgj-v45-commercial.cjs" || fail "Paid review flow marker missing."
grep -Fq 'dgj_v45_plan_codes' "$PAYLOAD/dist/dgj-v45-commercial.cjs" || fail "Employer plan-code system missing."
grep -Fq 'Payment receipt is required' "$PAYLOAD/dist/dgj-v45-commercial.cjs" || fail "Receipt validation missing."
grep -Fq 'dgj_v45_email_outbox' "$PAYLOAD/dist/dgj-v45-commercial.cjs" || fail "Transactional employer email outbox missing."
grep -Fq 'Job posting received – payment review | Dev Global Jobs' "$PAYLOAD/dist/dgj-v45-commercial.cjs" || fail "Paid submission email lifecycle missing."
grep -Fq 'Your job is now live | Dev Global Jobs' "$PAYLOAD/dist/dgj-v45-commercial.cjs" || fail "Paid live email lifecycle missing."
grep -Fq 'getVerificationMailer' "$PAYLOAD/dist/index.cjs" || fail "Existing SMTP transport bridge missing."
grep -Fq 'Premium Boost' "$PAYLOAD/dist/public/assets/dgj-v45-commercial.js" || fail "Premium Boost UI missing."
grep -Fq '5 Regular' "$PAYLOAD/dist/public/assets/dgj-v45-commercial.js" || fail "5 Regular quota UI missing."
grep -Fq '2 Featured' "$PAYLOAD/dist/public/assets/dgj-v45-commercial.js" || fail "2 Featured quota UI missing."
grep -Fq 'paypal.com/paypalme/tnwdgj' "$PAYLOAD/dist/public/assets/dgj-v45-commercial.js" || fail "PayPal payment link missing."
grep -Fq 'wise.com/pay/business/trendnovaworldlimited' "$PAYLOAD/dist/public/assets/dgj-v45-commercial.js" || fail "Wise payment link missing."
grep -Fq 'dgj-v45-commercial.js' "$PAYLOAD/dist/public/index.html" || fail "V45 UI not linked by index."
grep -Fq 'index-DGJ45auth-v43-youth.js' "$PAYLOAD/dist/public/index.html" || fail "V44 youth bundle reference not preserved."

echo "PASS: reviewed V45 feature payload verified."


echo
echo "3/8 PROTECTED SEO / BRAND REGRESSION CHECK"
for marker in \
  'DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27' \
  'devglobaljobs-social-share.png' \
  'const indexableJobs = latestJobs;' \
  'const indexableJobs = jobIds;' \
  'const indexableJobs = allJobIds;'
do
  grep -Fq "$marker" "$PAYLOAD/dist/index.cjs" || fail "Protected runtime marker missing: $marker"
done

grep -Fq '"data-testid":"section-youth-opportunities"' "$ASSETS/index-DGJ45auth-v43-youth.js" || fail "V43 Youth section marker missing from protected active bundle."
echo "PASS: Google Jobs, sitemap, V42 social, V43/V44 Youth and brand protections retained."


echo
echo "4/8 PRIVATE BACKUP — NEVER PUBLIC"
mkdir -p "$BACKUP"
chmod 700 "$BACKUP"
cp -af "$DIST/index.cjs" "$BACKUP/index.cjs"
cp -af "$PUBLIC/index.html" "$BACKUP/index.html"
[ -f "$DIST/dgj-v45-commercial.cjs" ] && cp -af "$DIST/dgj-v45-commercial.cjs" "$BACKUP/dgj-v45-commercial.cjs" || true
[ -f "$ASSETS/dgj-v45-commercial.js" ] && cp -af "$ASSETS/dgj-v45-commercial.js" "$BACKUP/dgj-v45-commercial.js" || true
[ -f "$ASSETS/dgj-v45-commercial.css" ] && cp -af "$ASSETS/dgj-v45-commercial.css" "$BACKUP/dgj-v45-commercial.css" || true
[ -f "$ASSETS/dgj-admin-logo-v45.png" ] && cp -af "$ASSETS/dgj-admin-logo-v45.png" "$BACKUP/dgj-admin-logo-v45.png" || true
chmod -R go-rwx "$BACKUP"
echo "Backup: $BACKUP"
echo "PASS: rollback copy stored only under /var/backups."


echo
echo "5/8 ATOMIC V45 INSTALL"
mkdir -p "$APP/private/payment-receipts"
chmod 700 "$APP/private" "$APP/private/payment-receipts"

tmp_server="$DIST/.index.cjs.v45.$$"
tmp_module="$DIST/.dgj-v45-commercial.cjs.$$"
tmp_index="$PUBLIC/.index.html.v45.$$"
tmp_ui="$ASSETS/.dgj-v45-commercial.js.$$"
tmp_css="$ASSETS/.dgj-v45-commercial.css.$$"
tmp_logo="$ASSETS/.dgj-admin-logo-v45.png.$$"

install -m 0644 "$PAYLOAD/dist/index.cjs" "$tmp_server"
install -m 0644 "$PAYLOAD/dist/dgj-v45-commercial.cjs" "$tmp_module"
install -m 0644 "$PAYLOAD/dist/public/index.html" "$tmp_index"
install -m 0644 "$PAYLOAD/dist/public/assets/dgj-v45-commercial.js" "$tmp_ui"
install -m 0644 "$PAYLOAD/dist/public/assets/dgj-v45-commercial.css" "$tmp_css"
install -m 0644 "$PAYLOAD/dist/public/assets/dgj-admin-logo-v45.png" "$tmp_logo"

mv -f "$tmp_module" "$DIST/dgj-v45-commercial.cjs"
mv -f "$tmp_ui" "$ASSETS/dgj-v45-commercial.js"
mv -f "$tmp_css" "$ASSETS/dgj-v45-commercial.css"
mv -f "$tmp_logo" "$ASSETS/dgj-admin-logo-v45.png"
mv -f "$tmp_index" "$PUBLIC/index.html"
mv -f "$tmp_server" "$DIST/index.cjs"
MUTATED=1

[ "$(sha "$DIST/index.cjs")" = "$NEW_SERVER_SHA" ]
[ "$(sha "$DIST/dgj-v45-commercial.cjs")" = "$NEW_MODULE_SHA" ]
[ "$(sha "$PUBLIC/index.html")" = "$NEW_INDEX_SHA" ]
[ "$(sha "$ASSETS/dgj-v45-commercial.js")" = "$NEW_UI_SHA" ]
[ "$(sha "$ASSETS/dgj-v45-commercial.css")" = "$NEW_CSS_SHA" ]
[ "$(sha "$ASSETS/dgj-admin-logo-v45.png")" = "$NEW_LOGO_SHA" ]
echo "PASS: only reviewed runtime/index and new V45 assets installed."


echo
echo "6/8 PM2 RELOAD + V45 DATABASE INITIALISATION"
pm2 reload "$PM2_APP" --update-env
sleep 4
curl -fsS --max-time 20 http://127.0.0.1:8080/api/jobs/stats >/dev/null || false
CONFIG="$(curl -fsS --max-time 20 http://127.0.0.1:8080/api/v45/commerce/config)"
printf '%s' "$CONFIG" | grep -Fq '"version":"45.1.0"' || false
printf '%s' "$CONFIG" | grep -Fq '"regular":5' || false
printf '%s' "$CONFIG" | grep -Fq '"featured":2' || false
printf '%s' "$CONFIG" | grep -Fq '"boost":49' || false
ADMIN_CODE="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 20 http://127.0.0.1:8080/api/v45/admin/summary || true)"
case "$ADMIN_CODE" in 401|403) : ;; *) echo "Unexpected unauthenticated admin endpoint status: $ADMIN_CODE"; false ;; esac
echo "PASS: V45 module loaded; additive commercial tables initialised; admin routes remain authenticated."


echo
echo "7/8 LIVE PROTECTED FILES + PUBLIC SECURITY CHECK"
[ "$(sha "$ASSETS/index-DGJ45auth-v43-youth.js")" = "$BASE_MAIN_SHA" ] || false
[ "$(sha "$PUBLIC/dgj-google-jobs-v27.js")" = "$BASE_GOOGLE_JOBS_SHA" ] || false
[ "$(sha "$PUBLIC/devglobaljobs-social-share.png")" = "$BASE_SOCIAL_SHA" ] || false
[ "$(sha "$PUBLIC/brand-contract.json")" = "$BASE_CONTRACT_SHA" ] || false
[ "$(sha "$PUBLIC/sw.js")" = "$BASE_SW_SHA" ] || false
[ "$(sha "$PUBLIC/dgj-brand-contract-v27.js")" = "$BASE_BRAND_JS_SHA" ] || false

# V45 receipts must never be under public.
if find "$PUBLIC" -type f \( -iname '*payment-receipt*' -o -iname '*receipt*.pdf' -o -iname '*receipt*.jpg' -o -iname '*receipt*.png' \) -print -quit | grep -q .; then
  echo "A receipt-like file is present under public web root."
  false
fi
[ "$(stat -c '%a' "$APP/private/payment-receipts")" = "700" ] || chmod 700 "$APP/private/payment-receipts"
echo "PASS: protected V44 files byte-for-byte unchanged; receipt storage is private."


echo
echo "8/8 FINAL PUBLIC HEALTH"
curl -fsS --max-time 20 https://devglobaljobs.com/ >/dev/null || false
curl -fsS --max-time 20 https://devglobaljobs.com/assets/dgj-v45-commercial.js?v=45.1.0 >/dev/null || false
curl -fsS --max-time 20 https://devglobaljobs.com/assets/dgj-admin-logo-v45.png >/dev/null || false
# Origin sitemap endpoint only: avoid treating a CDN cache delay as deployment corruption.
curl -fsS --max-time 20 http://127.0.0.1:8080/sitemap-index.xml | grep -q '<sitemapindex' || false

echo
echo "============================================================"
echo "SUCCESS: V45 COMMERCIAL POSTING + PREMIUM BOOST IS LIVE"
echo "============================================================"
echo "✓ White-screen post-success replaced by professional live confirmation"
echo "✓ 5 Regular + 2 Featured free per calendar month"
echo "✓ Free quota protected by verified account/email + business domain + hashed network/IP signal"
echo "✓ Regular paid review: USD 29 / 30-day paid placement priority"
echo "✓ Featured paid review: USD 79 / 45-day paid placement priority"
echo "✓ Premium Boost: USD 49 / 15 days + Premium Boost badge"
echo "✓ Paid posting and Boost payment-slip upload"
echo "✓ After free quota is exhausted: paid submission confirmation email queued to verified employer"
echo "✓ After admin publishes: second Your Job Is Now Live email queued with live link"
echo "✓ Transactional email outbox retries SMTP failures without rolling back payment/publishing"
echo "✓ Wise + PayPal + existing Wise bank-transfer details preserved"
echo "✓ Admin Promotion Centre: receipt review, edit, publish/live, activate/reject/end Boost"
echo "✓ Secure unique 1/3/6/12-month employer plan codes"
echo "✓ Configurable Regular / Featured / Boost monthly code allowances"
echo "✓ Plan codes stored hashed; full plaintext shown once at creation"
echo "✓ Paid/plan placements rank above free; active Premium Boost ranks first"
echo "✓ International branded admin login/dashboard with official Dev Global Jobs logo"
echo "✓ Admin login additional 5-attempt / 15-minute IP rate limit"
echo "✓ Receipts stored outside public web root with restricted permissions"
echo "✓ V44 Youth bundle unchanged"
echo "✓ Google JobPosting / sitemap / V42 social preview / service worker / brand lock preserved"
echo "✓ No npm build and no drizzle push"
echo "✓ Existing jobs, users and applications are not rewritten by deployment"
echo "✓ Database change is additive: isolated dgj_v45_* commercial tables only"
echo "Rollback backup: $BACKUP"
echo "============================================================"

trap - ERR INT TERM
MUTATED=0
