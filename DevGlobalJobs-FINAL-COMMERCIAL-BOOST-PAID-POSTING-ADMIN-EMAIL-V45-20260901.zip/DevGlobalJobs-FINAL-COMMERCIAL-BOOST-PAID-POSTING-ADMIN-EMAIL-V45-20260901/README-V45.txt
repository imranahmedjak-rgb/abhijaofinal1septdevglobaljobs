DEV GLOBAL JOBS V45
FINAL COMMERCIAL POSTING + PREMIUM BOOST + ADMIN PROMOTION CENTRE
Date: 1 September 2026
Revision: V45.1 transactional employer email lifecycle

PURPOSE
This package upgrades only the Dev Global Jobs employer monetisation / admin workflow on top of the exact successful V44 live baseline.

BUSINESS FLOW
1. Verified employer account receives 5 Regular + 2 Featured free posts per calendar month.
2. Free quota is protected using account, employer email, business-email domain (excluding common public email providers) and a hashed public network/IP signal.
3. Once the relevant free quota is exhausted, the same Post a Job submission opens secure paid review instead of a blank/white screen.
4. Regular paid placement: USD 29, commercial priority for 30 days.
5. Featured paid placement: USD 79, commercial priority for 45 days.
6. Employer pays using Wise, PayPal, or the existing Wise/local bank-transfer details already displayed on Post a Job.
7. Employer enters payment reference and uploads a PDF/JPG/PNG/WebP receipt (max 6 MB).
8. Paid job remains pending. It is NOT automatically published from a payment claim.
9. Admin Promotion Centre can download receipt, review job, edit it, Verify & Publish Live, or Reject.
10. After paid submission (only when free quota is exhausted), a transactional confirmation email is queued to the verified employer account.
11. When admin verifies and publishes the paid job, a second transactional "Your job is now live" email is queued with the live job link and Premium Boost invitation.
12. Successfully published jobs show a professional "Your job is now live" confirmation and a Premium Boost conversion option.

PREMIUM BOOST
- USD 49 / 15 days.
- Employer can pay + upload receipt, or use a prepaid employer plan code containing Boost allowance.
- Manual payment requests stay pending until admin clicks Verify & Activate.
- Active Boost receives a "Premium Boost" badge and highest commercial ranking priority.
- Admin can end a Boost.
- Boost expiry is automatic in the V45 commercial cache lifecycle.

COMMERCIAL RANKING
1. Active Premium Boost
2. Paid / plan-code Featured
3. Paid / plan-code Regular
4. Free / legacy Featured
5. Free / legacy Regular
6. Remaining standard jobs

Paid placement priority is independent of factual employer job closing dates; V45 does not invent Google Jobs validThrough dates.

EMPLOYER PLAN / BULK POSTING CODES
Admin can create multiple cryptographically random employer codes with:
- 1 month
- 3 months
- 6 months
- 12 months
- Monthly Regular allowance
- Monthly Featured allowance
- Monthly Premium Boost allowance
- Optional automatic Boost of code-posted jobs
- Employer email/domain binding
- Payment amount, method and reference notes

The plaintext code is shown once on creation. Only an HMAC hash plus a short masked identifier is retained in the database.

PAYMENT OPTIONS
Wise:
https://wise.com/pay/business/trendnovaworldlimited

PayPal:
https://www.paypal.com/paypalme/tnwdgj

Existing Wise bank/account details on the Post a Job page are preserved and remain available for bank transfer.
Support / payment follow-up:
info@devglobaljobs.com

RECEIPT SECURITY
- Receipts are NOT placed under dist/public.
- Default private directory: /var/www/devglobaljobs/private/payment-receipts
- Directory permission: 0700
- Receipt permission: 0600
- Random server filename
- Magic-byte validation: PDF/JPG/PNG/WebP
- Max receipt size: 6 MB
- Admin-authenticated download route only
- X-Content-Type-Options: nosniff
- Cache-Control: private, no-store

ADMIN SECURITY / BRANDING
- Official Dev Global Jobs logo on admin sign-in and dashboard.
- International Careers / Secure Administration presentation.
- Dedicated Promotion Centre.
- Existing admin authentication remains in place.
- Additional V45 admin login limiter: 5 attempts per public IP / 15 minutes.

DATABASE
V45 adds isolated commercial tables only:
- dgj_v45_allowance_usage
- dgj_v45_payment_requests
- dgj_v45_boosts
- dgj_v45_plan_codes
- dgj_v45_code_usage
- dgj_v45_email_outbox (transactional employer email retry/outbox)

No npm build.
No drizzle push.
No destructive migration.
Existing jobs, users, applications, Google Jobs fields, and existing content are not bulk rewritten by deployment.

PRESERVED V44 / V42 / V41 PROTECTIONS
- V44 active International Youth Opportunities SPA remains byte-for-byte unchanged.
- Google Jobs companion remains byte-for-byte unchanged.
- V42 social preview asset remains byte-for-byte unchanged.
- Brand contract / brand lock files remain byte-for-byte unchanged.
- Service worker remains byte-for-byte unchanged.
- Sitemap implementation markers remain present.

DEPLOYMENT
Run as root from the extracted release directory:

  bash ./deploy-v45-commercial-safe.sh

The deployer refuses to run unless the exact known V44 live baseline hashes match. V45.1 also bridges to the existing verified SMTP transport for transactional employer emails.
It creates a PRIVATE rollback copy under /var/backups only; it does not publish backups under dist/public.

EXPECTED FINAL LINE
SUCCESS: V45 COMMERCIAL POSTING + PREMIUM BOOST IS LIVE

ROLLBACK
If a deployment validation fails after mutation, the deployer restores the pre-V45 server/index and removes/restores V45 assets, then reloads PM2.
Additive dgj_v45_* tables may remain after a rollback if startup had already created them; they do not replace existing application tables.

TRANSACTIONAL EMPLOYER EMAILS
- Free-quota jobs remain immediate and do not enter paid-review email flow.
- After free quota is exhausted, a paid posting submission queues a Pending Verification email.
- After admin Verify & Publish Live, a second Your Job Is Now Live email is queued.
- V45 uses the existing SMTP configuration / info@devglobaljobs.com mail transport.
- Email delivery failure never rolls back a payment request or published job; queued mail retries safely.
- Premium Boost payment submission and activation also use the same transactional email outbox.
