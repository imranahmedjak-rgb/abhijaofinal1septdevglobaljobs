#!/usr/bin/env bash
set -Eeuo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"
sha256sum -c PAYLOAD-SHA256SUMS.txt >/dev/null
node --check payload/dist/index.cjs >/dev/null
node --check payload/dist/dgj-v45-commercial.cjs >/dev/null
node --check payload/dist/public/assets/dgj-v45-commercial.js >/dev/null
grep -Fq 'V45_PAID_REVIEW_REQUIRED' payload/dist/dgj-v45-commercial.cjs
grep -Fq 'dgj_v45_payment_requests' payload/dist/dgj-v45-commercial.cjs
grep -Fq 'dgj_v45_plan_codes' payload/dist/dgj-v45-commercial.cjs
grep -Fq 'dgj_v45_email_outbox' payload/dist/dgj-v45-commercial.cjs
grep -Fq 'Job posting received – payment review | Dev Global Jobs' payload/dist/dgj-v45-commercial.cjs
grep -Fq 'Your job is now live | Dev Global Jobs' payload/dist/dgj-v45-commercial.cjs
grep -Fq 'getVerificationMailer' payload/dist/index.cjs
grep -Fq 'Premium Boost' payload/dist/public/assets/dgj-v45-commercial.js
grep -Fq 'Payment slip / receipt' payload/dist/public/assets/dgj-v45-commercial.js
grep -Fq 'confirmation email has been queued' payload/dist/public/assets/dgj-v45-commercial.js
grep -Fq 'Promotion Centre' payload/dist/public/assets/dgj-v45-commercial.js
grep -Fq 'dgj-v45-commercial.js' payload/dist/public/index.html
grep -Fq 'index-DGJ45auth-v43-youth.js' payload/dist/public/index.html
printf '%s\n' 'PASS: V45.1 package checksums, syntax, commercial workflow and employer email lifecycle verified.'
