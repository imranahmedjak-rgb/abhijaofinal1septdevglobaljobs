DEV GLOBAL JOBS V48
PREMIUM EMPLOYER DASHBOARD + FORM-ONLY POST A JOB + ZERO-FLASH WORKFLOW

Target live baseline: exact successful V46 deployed on 2026-09-01.

Employer experience:
- Employer Dashboard is one premium workspace with stable scrolling.
- Every Post a Job control enters the Employer publishing journey.
- Signed-out visitors receive the Employer Sign In page, not the job-seeker flow and not a SPA 404.
- Google and verified-email sign-in return to the requested Employer destination.
- Post a Job is visually merged into the Employer Workspace.
- The public site header/footer, floating share/bookmark UI and redundant marketing stack are hidden inside Employer publishing.
- Only the useful listing-type selector and existing job form remain, with a compact live monthly allowance summary.
- V45 automatically opens paid review/receipt upload only after the allowance is exhausted.

Admin:
- login remains isolated
- route transitions hide underlying error/dashboard flashes
- authenticated sidebar/page scrolling is stabilised

No database migration in V48.

DEPLOY:
1. Run ./preflight-v48.sh
2. Run ./deploy-v48-premium-safe.sh as root on the exact successful V46 baseline.

The deployer safe-stops on baseline mismatch and creates a private rollback backup under /var/backups before mutation.

V48-FIXED deployment validator note:
- Production payload is identical to the reviewed V48 payload.
- Step 6 deployment verification now uses GET-based redirect checks instead of fragile HEAD checks.
- PM2 readiness uses a bounded 60-second health loop and prints the exact failing route/status if verification fails.
- No application feature, database schema, V45 commercial asset, or V46 employer module was changed by this validator correction.
