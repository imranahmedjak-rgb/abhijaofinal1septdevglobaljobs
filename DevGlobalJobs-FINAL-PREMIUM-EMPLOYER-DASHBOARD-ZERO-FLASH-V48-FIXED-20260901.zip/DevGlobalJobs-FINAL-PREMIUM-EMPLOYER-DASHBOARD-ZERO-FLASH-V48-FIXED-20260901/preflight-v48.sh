#!/usr/bin/env bash
set -Eeuo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
P="$HERE/payload"
fail(){ echo "FAIL: $*" >&2; exit 1; }
for c in sha256sum node grep find; do command -v "$c" >/dev/null 2>&1 || fail "Missing command: $c"; done
[ -f "$P/dist/index.cjs" ] || fail "runtime missing"
[ -f "$P/dist/public/index.html" ] || fail "index missing"
[ -f "$P/dist/public/assets/dgj-v48-premium.js" ] || fail "V48 JS missing"
[ -f "$P/dist/public/assets/dgj-v48-premium.css" ] || fail "V48 CSS missing"
node --check "$P/dist/index.cjs" >/dev/null
node --check "$P/dist/public/assets/dgj-v48-premium.js" >/dev/null
(cd "$HERE" && sha256sum -c PAYLOAD-SHA256SUMS.txt >/dev/null)
grep -Fq 'DGJ V48_PREMIUM_EMPLOYER_ZERO_FLASH_LOCK' "$P/dist/index.cjs" || fail "server V48 marker missing"
grep -Fq 'app2.get("/employer/post-job"' "$P/dist/index.cjs" || fail "server-owned employer post route missing"
grep -Fq 'Employer Sign In to Post a Job' "$P/dist/index.cjs" || fail "employer-only signed-out Post a Job missing"
grep -Fq 'window.location.replace(REDIRECT)' "$P/dist/index.cjs" || fail "clean auth return navigation missing"
grep -Fq 'dgj-v48-premium.css?v=48.0.0' "$P/dist/public/index.html" || fail "V48 CSS loader missing"
grep -Fq 'dgj-v48-premium.js?v=48.0.0' "$P/dist/public/index.html" || fail "V48 JS loader missing"
grep -Fq 'dgj-v46-employer.js?v=46.0.0' "$P/dist/public/index.html" || fail "V46 Employer Workspace loader missing"
grep -Fq 'dgj48-post-form-only' "$P/dist/public/assets/dgj-v48-premium.js" || fail "form-only employer publishing behavior missing"
grep -Fq 'Publish your next opportunity' "$P/dist/public/assets/dgj-v48-premium.js" || fail "premium post form header missing"
grep -Fq 'dgj48-public-chrome' "$P/dist/public/assets/dgj-v48-premium.js" || fail "nested public chrome suppression missing"
grep -Fq 'dgj48-admin-dashboard' "$P/dist/public/assets/dgj-v48-premium.css" || fail "admin stable-scroll styling missing"
grep -Fq 'Premium Employer Workspace' "$P/dist/public/assets/dgj-v48-premium.css" || fail "premium workspace styling marker missing"
if grep -Eq 'CREATE TABLE[^;]*dgj_v48|ALTER TABLE[^;]*dgj_v48' "$P/dist/index.cjs" "$P/dist/public/assets/dgj-v48-premium.js" 2>/dev/null; then fail "V48 must not introduce a database schema change"; fi
# Ensure V48 package does not ship replacements for protected V45/V46 business modules/assets.
if find "$P" -type f \( -name 'dgj-v45-commercial.cjs' -o -name 'dgj-v45-commercial.js' -o -name 'dgj-v45-commercial.css' -o -name 'dgj-v46-employer.cjs' -o -name 'dgj-v46-employer.js' -o -name 'dgj-v46-employer.css' \) -print -quit | grep -q .; then fail "V48 payload unexpectedly contains protected V45/V46 replacements"; fi
echo "PASS: V48 premium Employer Dashboard, form-only Post a Job, zero-flash auth workflow and Admin scroll stability verified."
