#!/usr/bin/env bash
set -Eeuo pipefail
BASE="$(cd "$(dirname "$0")" && pwd)"
P="$BASE/payload/dist/public"
A="$P/assets"
fail(){ echo "SAFE STOP: $*" >&2; exit 1; }

sha256sum -c "$BASE/PAYLOAD-SHA256SUMS.txt" --directory="$BASE/payload" >/dev/null 2>&1 || {
  cd "$BASE/payload"; sha256sum -c "$BASE/PAYLOAD-SHA256SUMS.txt" >/dev/null;
}
node --check "$A/dgj-v51-employer.js" >/dev/null
node --check "$A/dgj-v49-premium.js" >/dev/null

[ "$(find "$BASE/payload" -type f | wc -l)" -eq 4 ] || fail "V55 payload must contain exactly four reviewed frontend files."
[ ! -e "$BASE/payload/dist/index.cjs" ] || fail "Main server runtime must not be in V55 payload."
[ ! -e "$BASE/payload/dist/dgj-v51-recruitment.cjs" ] || fail "Recruitment backend must not be in V55 payload."

python3 - "$A/dgj-v51-employer.js" "$A/dgj-v49-premium.js" "$A/dgj-v51-recruitment.css" "$P/index.html" <<'PY'
from pathlib import Path
import sys,re
emp,v49,css,idx=[Path(x).read_text() for x in sys.argv[1:]]
def need(cond,msg):
    if not cond: raise SystemExit('SAFE STOP: '+msg)

# DOM-race regression: previous insertBefore failure must not return.
need('insertBefore' not in emp and 'insertBefore' not in v49,'unsafe insertBefore returned')

# Employer dashboard: exactly one in-flight overview request and no automatic retry storm.
need('portalBusy=false,portalRetryBlocked=false' in emp,'portal request state guard missing')
need("if(portalBusy)return;portalBusy=true;ensurePortalFrame()" in emp,'single-flight overview guard missing')
need("!portalData&&!portalBusy&&!portalRetryBlocked" in emp,'dashboard retry-loop guard missing')
need("portalRetryBlocked=true" in emp and "portalRetryBlocked=false;loadPortal()" in emp,'manual retry contract missing')

# Post Job: shell is created/mounted before employer API latency is awaited.
post=emp[emp.index('async function employerPostShell(){'):emp.index('\nfunction adminEmployers()',emp.index('async function employerPostShell(){'))]
need(post.index('ensureEmployerPostShell()') < post.index("api('/api/v46/employer/me')"),'Post a Job still waits for /employer/me before rendering shell')
ensure=emp[emp.index('function ensureEmployerPostShell(){'):emp.index('async function employerPostShell(){')]
need('mount.appendChild(root)' in ensure,'Post a Job root is not mounted immediately')
need('dgj55-post-placeholder' in emp,'stable in-workspace form placeholder missing')
need("setInterval(tick,2500)" in emp,'employer fallback polling was not reduced')

# No extra /employer/post-job navigation inside authenticated employer controls.
need("location.href='/post-job?employer=1'" in emp,'internal direct Post a Job route missing')
need("location.assign((EMPLOYER||EMPLOYER_POST)?'/post-job?employer=1':'/employer/post-job')" in v49,'public/authenticated Post a Job routing split missing')
need("location.assign('/employer/post-job')" not in v49,'two-hop Post a Job navigation remains')

# V49 must not create full-screen Employer Workspace loaders.
need("if(EMPLOYER||EMPLOYER_POST){boot(false)" in v49,'employer full-screen boot was not disabled')
need("else if(ADMIN)overlayCard" in v49,'admin-only overlay contract missing')
need("dgj55-post-ready" in v49 and "dgj55-post-timeout" in v49,'form readiness/fail-fast contract missing')
# Readiness must happen only after page/form structure has been identified.
i_page=v49.index("if(!page)return false")
i_ready=v49.index("document.documentElement.classList.remove('dgj55-post-pending')")
need(i_ready>i_page,'Post root can become visible before form structure is validated')

# Critical CSS hides public SPA root before first paint and keeps it hidden until transformed.
need('html.dgj55-employer-post body>#root{visibility:hidden!important}' in css,'initial public Post a Job flash guard missing')
need('html.dgj55-employer-post:not(.dgj55-post-ready) .dgj46-post-content>#root' in css,'pending form visibility guard missing')
need('html.dgj55-employer-post.dgj55-post-ready .dgj46-post-content>#root' in css,'ready form visibility restore missing')
need('html.dgj55-employer-route #dgj-splash' in css,'employer global splash suppression missing')

# Index must classify employer routes before premium/employer JS and cache-bust changed files.
need('dgj-v55-employer-route-guard-js' in idx,'early V55 route classifier missing')
need(idx.index('dgj-v55-employer-route-guard-js') < idx.index('dgj-v49-premium-js') < idx.index('dgj-v46-employer-js'),'critical script order wrong')
need('/assets/dgj-v49-premium.js?v=55.0.0' in idx,'V49 V55 cache bust missing')
need('/assets/dgj-v51-employer.js?v=55.0.0' in idx,'Employer V55 cache bust missing')
need('/assets/dgj-v51-recruitment.css?v=55.0.0' in idx,'V55 CSS cache bust missing')
need('dgjEmployerPost || dgjEmployerRoute' in idx,'global splash is not bypassed for employer routes')

print('PASS: V55 zero-flash Employer Workspace, single-flight dashboard and direct Post a Job route contracts verified.')
PY

echo "PASS: V55 offline preflight complete."
