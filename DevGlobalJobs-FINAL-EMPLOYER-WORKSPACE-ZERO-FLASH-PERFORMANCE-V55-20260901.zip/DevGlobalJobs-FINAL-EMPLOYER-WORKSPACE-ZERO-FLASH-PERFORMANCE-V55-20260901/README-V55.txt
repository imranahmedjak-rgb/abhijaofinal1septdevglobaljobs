Dev Global Jobs V55 - Zero-Flash Employer Workspace + Performance Stability

Purpose
- Remove the public Post a Job flash before the authenticated Employer Workspace form.
- Remove full-screen Employer Workspace loading overlays/spinners.
- Stop concurrent /api/v46/employer/overview request storms caused by DOM mutation ticks.
- Remove the intermediate /employer/post-job navigation for authenticated employer controls.
- Render the Employer Post a Job shell before employer-session API latency.
- Fail fast with an explicit retry action if the real job form does not become ready.

Scope
Frontend only: dgj-v51-employer.js, dgj-v49-premium.js, dgj-v51-recruitment.css, index.html.
No backend, database, payment, ATS, CV, retention, Google Jobs, sitemap, Youth, social, brand or service-worker changes.

Deployment
Run preflight-v55.sh, then deploy-v55-zero-flash-safe.sh.
The deployer accepts only the exact V54 production baseline and creates a private rollback backup first.
